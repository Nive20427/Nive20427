import React, { useState } from 'react';
import FormData from "../components/FormData";

function Data() {

  return (
    <div>
      <FormData showUsers={true}/>

    </div>
  )
}

export default Data

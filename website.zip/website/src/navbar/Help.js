import React from 'react';
import { FaFacebook, FaTwitter, FaInstagram, FaLinkedin, FaYoutube } from 'react-icons/fa';
import { Container, Row, Col, Button, Card } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap-icons/font/bootstrap-icons.css';
import './Help.css';

function Help () {
  return (
    <div>
      <header className="bg-purple text-white py-5" style={{backgroundImage:'url("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRP79AD5gSOQEmuFuuT-FTpy-xKrjMov6zUPQ&s")' , backgroundSize: 'cover', backgroundRepeat: 'no-repeat', backgroundPosition: 'center'}}>
        <Container>
          <Row>
            <Col>
              <h1>We help startups launch their products</h1>
              <p>Etiam sed tincidunt consequat proin vestibulum classNameme at.</p>
              <Button variant="danger" className="rounded-pill">
                <i className="bi bi-play-fill"></i>
              </Button>
            </Col>
          </Row>
        </Container>
      </header>

      <section className="py-5">
        <Container>
          <Row className="text-center mb-4">
            <Col>
              <h2>OUR SERVICES</h2>
              <p>
                We craft digital, graphic and dimensional thinking, to create category leading brand experiences that have
                meaning and add value for our clients.
              </p>
            </Col>
          </Row>

          <Row>
            <Col md={4} className="mb-4">
              <Card className="h-100" style={{backgroundImage:'url("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQj-lRI6VM87DrFeTQP89jIV9xCAY6HRjJwgA&s")' , backgroundSize: 'cover', backgroundRepeat: 'no-repeat', backgroundPosition: 'center'}}>
                <Card.Body >
                  <i className="bi bi-browser-chrome display-1 text-primary"  ></i>
                  <Card.Title>Digital Design</Card.Title>
                  <Card.Text>Some quick example text to build on the card title and make up the bulk of the card's content.</Card.Text>
                </Card.Body>
              </Card>
            </Col>

            <Col md={4} className="mb-4">
              <Card className="h-100"  style={{backgroundImage:'url("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTbOpW0GhRkrXrjJThWTMDQp8kDAV9OLcTHIg&s")' , backgroundSize: 'cover', backgroundRepeat: 'no-repeat', backgroundPosition: 'center'}}>
                <Card.Body>
                  <i className="bi bi-palette display-1 text-primary"></i>
                  <Card.Title>Unlimited Colors</Card.Title>
                  <Card.Text>Credibly brand standards compliant users without extensible services. Anbh euismod tincidunt ut laoreet.</Card.Text>
                </Card.Body>
              </Card>
            </Col>

            <Col md={4} className="mb-4">
              <Card className="h-100"  style={{backgroundImage:'url("https://e1.pxfuel.com/desktop-wallpaper/709/713/desktop-wallpaper-blur-background-for-editing-i-picsart-blur-nature-mobile.jpg")' , backgroundSize: 'cover', backgroundRepeat: 'no-repeat', backgroundPosition: 'center'}}>
                <Card.Body>
                  <i className="bi bi-lightbulb display-1 text-primary"></i>
                  <Card.Title>Strategy Solutions</Card.Title>
                  <Card.Text>Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean necessary regailai.</Card.Text>
                </Card.Body>
              </Card>
            </Col>
          </Row>

          <Row className="text-center">
            <Col>
              <Button variant="primary" className="me-3">
                View Demo
              </Button>
              <Button variant="outline-primary">More info / Download</Button>
            </Col>
          </Row>
        </Container>
      </section>


    <footer className="bg-dark text-white py-4">
      <div className="container">
        <div className="row">
          <div className="col-md-6">
            <h5>About Us</h5>
            <p>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed auctor, magna non bibendum tincidunt, nunc augue sollicitudin ligula, a pulvinar nunc mauris at ante.
            </p>
          </div>
          <div className="col-md-6">
            <h5>Follow Us</h5>
            <div className="d-flex justify-content-end">
              <a href="https://www.facebook.com/" className="mx-2 text-white">
                <FaFacebook />
              </a>
              <a href="https://twitter.com/i/flow/login" className="mx-2 text-white">
                <FaTwitter />
              </a>
              <a href="https://www.instagram.com/" className="mx-2 text-white">
                <FaInstagram />
              </a>
              <a href="https://in.linkedin.com/" className="mx-2 text-white">
                <FaLinkedin />
              </a>
              <a href="https://www.youtube.com/" className="mx-2 text-white">
                <FaYoutube />
              </a>
            </div>
          </div>
        </div>
        <hr className="my-4" />
        <div className="row">
          <div className="col-12 text-center">
            <p>&copy; 2024 Your Company. All rights reserved.</p>
          </div>
        </div>
      </div>
    </footer>
    </div>
  );
};

export default Help;
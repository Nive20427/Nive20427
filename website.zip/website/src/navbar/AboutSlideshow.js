import React, { useState } from 'react';
import AboutSlide from './AboutSlide';
import 'bootstrap/dist/css/bootstrap.min.css';
import './About.css'
const AboutSlideshow= () => {
  const [currentSlide, setCurrentSlide] = useState(0);

  const slideData = [
    {
      title: 'overview',
      description: 'Software development refers to a set of computer science activities that are dedicated to the process of creating, designing, deploying, and supporting software.Software engineers apply engineering principles to build software and systems to solve problems. They use modeling language and other tools to devise solutions that can often be applied to problems in a general way, as opposed to merely solving for a specific instance or client. Software engineering solutions adhere to the scientific method and must work in the real world, as with bridges or elevators. Their responsibility has grown as products have become increasingly intelligent with the addition of microprocessors, sensors, and software.',
      imageSrc: 'https://cdn.pixabay.com/photo/2020/03/25/14/57/orbs-4967554_640.jpg', 
    },
    {
      title: 'Software Develper',
      description: 'Software developers have a less formal role than engineers and can be closely involved with specific project areas — including writing code. At the same time, they drive the overall software development lifecycle — including working across functional teams to transform requirements into features, manage development teams and processes, and conduct software testing and maintenance.The work of software development isn’t confined to coders or development teams. Professionals such as scientists, device fabricators and hardware makers also create software code even though they are not primarily software developers. Nor is it confined to traditional information technology industries such as software or semiconductor businesses',
      imageSrc: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSMQfBQw20W0WBVLnpUyKktfHZAtd3_UxKsSA&s', 
    },
    {
      title: 'Features',
      description: 'Artificial intelligence (AI): AI enables software to emulate human decision-making and learning. Neural networks, machine learning, natural language processing and cognitive capabilities present developers and businesses with the opportunity to offer products and services that disrupt marketplaces and leap ahead of the competition.',
      imageSrc: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT7po4mn45FU7Ey1fDnMb4o_FQRMLTw4fDp3g&s', 
    },
    {
      title: ' Glossary',
      description: 'Agile development, Capability Maturity Model (CMM) , DevOps, Rapid application development (RAD),Scaled Agile Framework (SAFe),Waterfall',
      imageSrc: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRMSVcM6Lhzp2zbTdbZKEkD4GDpZxz07jRldg&s', 
    },
 
  ];

  const handleNextSlide = () => {
    setCurrentSlide((prevSlide) => (prevSlide + 1) % slideData.length);
  };

  const handlePrevSlide = () => {
    setCurrentSlide((prevSlide) => (prevSlide - 1 + slideData.length) % slideData.length);
  };

  return (
    <div id="aboutSlideshow" className="carousel slide" data-bs-ride="carousel">
      <div className="carousel-inner">
        {slideData.map((slide, index) => (
          <AboutSlide
            key={index}
            title={slide.title}
            description={slide.description}
            imageSrc={slide.imageSrc}
            className={index === currentSlide ? 'carousel-item active' : 'carousel-item'}
          />
        ))}
      </div>
      <button
        className="carousel-control-prev"
        type="button"
        data-bs-target="#aboutSlideshow"
        data-bs-slide="prev"
        onClick={handlePrevSlide}
      >
        <span className="carousel-control-prev-icon" aria-hidden="true"></span>
        <span className="visually-hidden">Previous</span>
      </button>
      <button
        className="carousel-control-next"
        type="button"
        data-bs-target="#aboutSlideshow"
        data-bs-slide="next"
        onClick={handleNextSlide}
      >
        <span className="carousel-control-next-icon" aria-hidden="true"></span>
        <span className="visually-hidden">Next</span>
      </button>
    </div>
  );
};

export default AboutSlideshow;

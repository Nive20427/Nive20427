import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useNavigate } from 'react-router-dom';
import '../components/Login.css';

function LoginPage({ signup }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showNewUser, setShowNewUser] = useState(false);
  const [newUsername, setNewUsername] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(false);
  const navigate = useNavigate();

  //  console.log('aas',signup)
  const handleLogin = async (e) => {
    e.preventDefault();
        let id =[];
        let finalData 
    try {
      const response = await axios.get('http://localhost:9000/users', {
        params: {
          id,
          email,
          password,
        },
      });
      if (response.data.length > 0) {
        console.error('Error success');
        navigate('/home')
      } else {
        toast.error('Invalid email or password');

      }
    } catch (error) {
      console.error('Error:', error);
      toast.error('An error occurred. Please try again later.');
    }
  };
  useEffect(() => {
    if (signup == true) {
      setShowNewUser(true);
    } else {
      setShowNewUser(false);
    }

  }, [signup])
  const handleNewUser = async (e) => {
    e.preventDefault();

    try {
      await axios.post('http://localhost:9000/users', {
        username: newUsername,
        email: newEmail,
        password: newPassword,
      });
      toast.success('Registration successful!');
      setShowNewUser(false);
      setNewUsername('');
      setNewEmail('');
      setNewPassword('');
    } catch (error) {
      console.error('Error:', error);
      toast.error('An error occurred. Please try again later.');
    }
  };

  return (
    <div className="container-fluid vh-100 d-flex justify-content-center align-items-center" style={{ backgroundImage: "url('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRJhmfOcGJrt6F-3ykaLapX41UydcSjslS0Sw&s')", backgroundSize: 'cover', backgroundRepeat: 'no-repeat', backgroundPosition: 'center' }}>

      <div className="card p-3 rounded-lg col-md-6 col-lg-4 col-xl-3" >
        <div className="card-body" style={{ backgroundImage: "url('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS76aEhnAWQTEk9L92a6lXW78HhXofDtvXfdGnWdpF9sv1fICtKpYh5Vh3XkQ&s')", backgroundSize: 'cover', backgroundRepeat: 'no-repeat', backgroundPosition: 'center' }}>
          <h5 className="card-title text-center mb-4">{showNewUser ? 'New User' : 'Sign In'}</h5>
          {showNewUser ?
            <form onSubmit={handleNewUser}>
              <div className="form-group" style={{ margin: '10px', width: '100%' }} >
                <label htmlFor="newUsername">Username</label>
                <input type="text" className="form-control" id="newUsername" placeholder="Enter username" value={newUsername} onChange={(e) => setNewUsername(e.target.value)} />
              </div>
              <div className="form-group" style={{ margin: '10px', width: '100%' }}>
                <label htmlFor="newEmail">Email</label>
                <input type="email" className="form-control" id="newEmail" placeholder="Enter email" value={newEmail} onChange={(e) => setNewEmail(e.target.value)} />
              </div>
              <div className="form-group" style={{ margin: '10px', width: '100%' }}>
                <label htmlFor="newPassword">Password</label>
                <input type="password" className="form-control" id="newPassword" placeholder="Enter password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} />
              </div>
              <button type="submit" className="btn btn-primary btn-block mt-4">
                Register
              </button>
            </form>
            :
            <form onSubmit={handleLogin}>
              <div className="form-group" style={{ margin: '10px', width: '100%' }}>
                <label htmlFor="email">Email</label>
                <input type="email" className="form-control" id="email" placeholder="Enter email" value={email} onChange={(e) => setEmail(e.target.value)} />
              </div>
              <div className="form-group" style={{ margin: '10px', width: '100%' }}>
                <label htmlFor="password">Password</label>
                <input type="password" className="form-control" id="password" placeholder="Enter password" value={password} onChange={(e) => setPassword(e.target.value)} />
              </div>
              <div className="form-group form-check">
                <input type="checkbox" className="form-check-input" id="rememberMe" checked={rememberMe} onChange={(e) => setRememberMe(e.target.checked)} />
                <label className="form-check-label" htmlFor="rememberMe">
                  Remember me
                </label>
              </div>
              <button type="submit" className="btn btn-primary btn-block mt-4">
                Sign In
              </button>
            </form>
          }
          <div className="text-center mt-3">
            <small>
              {showNewUser ?
                <span>
                  Already a member? <a href="#" onClick={() => setShowNewUser(false)}>Sign in</a>
                </span>
                :
                <span>
                  Not a member? <a href="#" onClick={() => setShowNewUser(true)}>Sign Up</a>
                </span>
              }
            </small>
          </div>
        </div>
      </div>
      <ToastContainer />
    </div>

  );
};
export default LoginPage;
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import FormTable from './FormTable';
import RegisterForm from './RegisterForm';


function FormData (showUsers)  {
  const [showForm, setShowForm] = useState(false);
  const [users, setUsers] = useState([]);
  const [editing, setEditing] = useState(false);
  const [selectedUser, setSelectedUser] = useState(null);
  const [editingRow, setEditingRow] = useState(null);
  const [editingMode, setEditingMode] = useState(false);



  const fetchUsers = async () => {
    try {
      const response = await axios.get('http://localhost:8000/userbio');
      setUsers(response.data);
    } catch (error) {
      console.error('Error fetching users:', error);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);
  useEffect(() => {
 if(showUsers == true){
     setShowForm(true)
 } else{

 }

  }, [showUsers])
  const handleSubmit = async (newUser) => {
    setShowForm(false);

  };

  const handleGoBack = () => {
    setShowForm(true);
  };

  const handleSave = async (id, updatedUser) => {
    console.log(id, updatedUser)
    //  let data =JSON.stringfy()
    await axios.put(`http://localhost:8000/userbio/${id}`, updatedUser).then((res) => { console.log("res", res) })
    setEditingMode(false)
    fetchUsers();

  };
  const handleDelete = async (id) => {
    console.log(id)
    try {
      const response = await axios.delete(`http://localhost:8000/userbio/${id}`);
      console.log("response_", response);
      fetchUsers();
    } catch (error) {
      console.error('Error updating user:', error);
    }
  }
  return (
    <div className="container">
      <div className="row justify-content-center">
        <div className="col-md-8">
          <div className="mt-5 card-header">
            <h2>Registration Form</h2>
          </div>
          {showForm ?
            <RegisterForm onSubmit={handleSubmit} />
            :
            <div>
              <h2>Registered Users</h2>
              <FormTable data={users} handleDelete={handleDelete} setUsers={setUsers}
                handleSave={handleSave} setEditingRow={setEditingRow} editingRow={editingRow} editingMode={editingMode} setEditingMode={setEditingMode} />
              <button className="btn btn-primary mt-3" onClick={handleGoBack}>
                Go Back
              </button>
            </div>
          }
        </div>

      </div>
    </div>
  );
};
export default FormData;
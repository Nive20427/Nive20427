// import logo from './logo.svg';
// import './App.css';
// import React, { useState } from 'react'

// import HomeComponent from './Components/Home';
// import ParentWithoutContext from './Components/Usecontext/Parentwithoutcontext';
// import ParentssingcContext from './Components/Usecontext/ParentusingcContext';
// import Inputincrementer from './Components/inpuboxCount/InputCountincrement';
// import Reducers from './Components/UseReducers/UseReducer';
// import CustomTable from './Components/table';
// import NavBar from './Components/NavBar/NavBar';
// import UseDebugTest from './Components/UseDebugValue/UseDebugTest';
// import HeaderSmoothScrooling from './Components/ScrollModel/HeaderSmoothScrooling';
// import LandingPage from './TODOList/TodoComponent/LandingPage';
// import QRLandingPage from './qr-code-component-main/QRLandingPage';
// import IsprimeorNot from './Components/PrimeorNot/IsprimeorNot';
// import IsPrimeINRange from './Components/PrimeorNot/IsPrimeINRange';
// import MainLandingPage from './Components/MainLandingPage';
// import router from './routes/route';
// import { Route, Routes } from 'react-router';
// import Landingpage from './Components/LandingPage';

// function App() {
//   const [users] = useState[
//     {
//       "name": "asd",
//       "email": "asd@gamila.comn"
//     }
//   ]

//   return (
//     <div className="App">
//       {/* <NavBar/> */}
//       {/* <HomeComponent/> */}
//       {/* <UseDebugTest/> */}
//       {/* <ParentWithoutContext/> */}
//       {/* <ParentssingcContext/> */}
//       {/* <Inputincrementer/> */}
//       {/* <Reducers />
//       <CustomTable/> */}
//       {/* <HeaderSmoothScrooling/> */}
//       {/* <LandingPage/> */}
//       {/* <QRLandingPage/> */}
//       {/* <IsprimeorNot/> */}
//       {/* <IsPrimeINRange/> */}
//       {/* <div id='aaa'>
//         t987
//         </div> */}
//       {/* <MainLandingPage/> */}
      
//     </div>
//   );
// }

// export default App;
import "./App.css";
import React from "react";
import { Link, Route, Routes } from "react-router-dom";

import Home from "../src/Pages/Home";
import Courses from "../src/Pages/Courses";
import Live from "../src/Pages/Live";
import Contact from "../src/Pages/Contact";
import Login from "./Components/Login/Login";
import Appaa from "./Pages/testaaaa";

function App() {
  return (
    <div className="container">
      <nav>
        <ul>
          <Link to="/" class="list">
            Home
          </Link>
          <Link to="/course" class="list">
            Courses
          </Link>
          <Link to="/live" class="list">
            Live course
          </Link>
          <Link to="/contact" class="list">
            Contact
          </Link>
          <Link to="/Login" class="list">
            Login
          </Link>
        </ul>
      </nav>

      {/* Defining routes path and rendering components as element */}
      {/* <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/course" element={<Courses />} />
        <Route path="/live" element={<Live />} />
        <Route path="/contact" element={<Contact />} />
        <Route path ='/login' element={<Login/>}/>
      </Routes> */}
      <Appaa/>
    </div>
  );
}

export default App;


// export const routes=[
//     {
//         component: Landingpage,
//         key: "/"
//     },
//     {
//         component: Landingpage,
//         key: "/home"
//     }
// ]
import * as React from "react";
import { createRoot } from "react-dom/client";
import {
    createBrowserRouter,
    RouterProvider,
    Route,
    Link,
    Routes,
} from "react-router-dom";
import HomeComponent from "../Components/Home";
import Landingpage from "../Components/LandingPage";
// const router = createBrowserRouter([
//     {
//         path: "/",
//         element: ( <HomeComponent/>
//             // <div>
//             //     <h1>Hello World</h1>
//             //     <Link to="about">About Us</Link>
//             // </div>
//         ),
//     },
//     {
//         path: "about",
//         element: <div>About</div>,
//     },
// ]);
function router() {
    return (
        <></>)
}
export default router;
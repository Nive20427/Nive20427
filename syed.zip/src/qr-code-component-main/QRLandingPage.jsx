import React from 'react'
import qr from './images/image-qr-code.png'
// import  '../qr-code-component-main/QRLandingpage.css'


function QRLandingPage() {


  return (<>
    <div className='maindiv'>
      <div className='content'>
        <div id='imgqr2'>
          <img src={qr} className='imgqr' width={250} />
        </div>
        <div className='text'>
          <h4>Improve youe Front-end skills by building projects</h4>
          <p>Scan the QR code to visit frontend Mentoe and take your coding skills to the next</p>
        </div>
      </div>
      {/* <div>
          
        </div> */}

    </div>
  </>
  )
}

export default QRLandingPage
import React from 'react'

function LandingPage() {

    
  return (
    <div >LandingPage</div>
  )
}

export default LandingPage
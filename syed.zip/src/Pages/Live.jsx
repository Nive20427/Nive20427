import React from 'react'

function Live() {
  return (
    <div>Live</div>
  )
}

export default Live
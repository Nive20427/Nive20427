import React from 'react'

function Courses() {
  return (
    <div>Courses</div>
  )
}

export default Courses
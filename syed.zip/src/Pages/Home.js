import React from 'react'
import Accordion from 'react-bootstrap/Accordion';

function Home() {
  return (

    <>
      <div style={{ width: 1940, height: 3761, position: 'relative', background: '#1C1D22', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', display: 'inline-flex' }}>
        <div style={{ width: 1940, height: 950, position: 'relative', backgroundImage: 'url(https://via.placeholder.com/1940x950)' }}>
          <div style={{ width: 1940, height: 950, left: 0, top: 0, position: 'absolute', background: 'rgba(0, 0, 0, 0.65)' }} />
          <div style={{ left: 517, top: 313, position: 'absolute', flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'center', gap: 40, display: 'inline-flex' }}>
            <div style={{ flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 20, display: 'flex' }}>
              <div style={{ justifyContent: 'center', alignItems: 'center', display: 'inline-flex' }}>
                <div style={{ width: 887, textAlign: 'center', color: 'white', fontSize: 64, fontFamily: 'Montserrat', fontWeight: '600', wordWrap: 'break-word' }}>Transform Your Business with RapidQube</div>
              </div>
              <div style={{ justifyContent: 'center', alignItems: 'center', display: 'inline-flex' }}>
                <div style={{ width: 887, textAlign: 'center', color: '#00930F', fontSize: 24, fontFamily: 'Montserrat', fontWeight: '500', wordWrap: 'break-word' }}>RapidQube delivers innovative tech solutions to drive growth, enhance efficiency, and optimize performance. Our expert team ensures seamless integration and tailored services for maximum impact.</div>
              </div>
            </div>
            <div style={{ justifyContent: 'flex-start', alignItems: 'flex-start', gap: 28, display: 'inline-flex' }}>
              <div style={{ paddingLeft: 28, paddingRight: 28, paddingTop: 10, paddingBottom: 10, background: '#07A117', justifyContent: 'center', alignItems: 'center', gap: 10, display: 'flex' }}>
                <div style={{ color: 'white', fontSize: 20, fontFamily: 'Montserrat', fontWeight: '600', wordWrap: 'break-word' }}>Get Started</div>
              </div>
              <div style={{ paddingLeft: 28, paddingRight: 28, paddingTop: 10, paddingBottom: 10, border: '1px white solid', justifyContent: 'center', alignItems: 'center', gap: 10, display: 'flex' }}>
                <div style={{ color: 'white', fontSize: 20, fontFamily: 'Montserrat', fontWeight: '600', wordWrap: 'break-word' }}>Learn more</div>
              </div>
            </div>
          </div>
        </div>
        <div style={{ paddingTop: 43, paddingBottom: 44, paddingLeft: 59.80, paddingRight: 64, background: '#111310', borderTopLeftRadius: 20, borderTopRightRadius: 20, overflow: 'hidden', justifyContent: 'flex-start', alignItems: 'center', gap: 247.20, display: 'inline-flex' }}>
          <div style={{ width: 247, height: 74, position: 'relative' }}>
            <div style={{ left: 17, top: 0, position: 'absolute', color: 'white', fontSize: 36, fontFamily: 'Montserrat', fontWeight: '700', wordWrap: 'break-word' }}>Rapidqube</div>
            <div style={{ left: 0, top: 50, position: 'absolute', color: '#07A117', fontSize: 14, fontFamily: 'Montserrat', fontWeight: '600', lineHeight: 23.80, wordWrap: 'break-word' }}>Transforming Business Paradigms</div>
          </div>
          <div style={{ alignSelf: 'stretch', justifyContent: 'flex-start', alignItems: 'center', gap: 57, display: 'inline-flex' }}>
            <div style={{ justifyContent: 'flex-start', alignItems: 'flex-start', gap: 96, display: 'flex' }}>
              <div style={{ color: 'white', fontSize: 15, fontFamily: 'Montserrat', fontWeight: '600', wordWrap: 'break-word' }}>HOME</div>
              <div style={{ justifyContent: 'flex-start', alignItems: 'center', gap: 8, display: 'flex' }}>
                <div style={{ color: 'white', fontSize: 15, fontFamily: 'Montserrat', fontWeight: '600', wordWrap: 'break-word' }}>PRODUCTS </div>
                <div style={{ width: 14.34, height: 8.07, transform: 'rotate(-180deg)', transformOrigin: '0 0', background: 'white' }}></div>
              </div>
              <div style={{ width: 89, height: 18, paddingRight: 7, justifyContent: 'flex-start', alignItems: 'center', display: 'flex' }}>
                <div style={{ color: 'white', fontSize: 15, fontFamily: 'Montserrat', fontWeight: '600', wordWrap: 'break-word' }}>ABOUT US</div>
              </div>
              <div style={{ color: '#07A117', fontSize: 15, fontFamily: 'Montserrat', fontWeight: '600', wordWrap: 'break-word' }}>SERVICES</div>
              <div style={{ color: 'white', fontSize: 15, fontFamily: 'Montserrat', fontWeight: '600', wordWrap: 'break-word' }}>CONTACT US</div>
            </div>
            <div style={{ paddingLeft: 28, paddingRight: 28, paddingTop: 10, paddingBottom: 10, background: '#07A117', justifyContent: 'center', alignItems: 'center', gap: 10, display: 'flex' }}>
              <div style={{ color: 'white', fontSize: 15, fontFamily: 'Montserrat', fontWeight: '700', wordWrap: 'break-word' }}>Request a Demo</div>
            </div>
          </div>
        </div>
        <div style={{ width: 1673, height: 2179, position: 'relative', background: '#1C1D22', borderRadius: 28, overflow: 'hidden' }}>
          <div style={{ height: 270, padding: 10, left: 670, top: 120, position: 'absolute', justifyContent: 'center', alignItems: 'center', gap: 10, display: 'inline-flex' }}>
            <div style={{ width: 903, color: 'white', fontSize: 32, fontFamily: 'Poppins', fontWeight: '400', lineHeight: 51.20, letterSpacing: 0.32, wordWrap: 'break-word' }}>Lorem ipsum dolor sit amet, consectetur adipiscing  lorem dolor sed. m dolor sit amet, consectetur adipiscing  lorem dolor sed. ipsum dolor sit amet, consectetur adipiscing  lorem d</div>
          </div>
          <div style={{ left: 80, top: 120, position: 'absolute', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 32, display: 'inline-flex' }}>
            <div style={{ width: 270, height: 0, transform: 'rotate(-90deg)', transformOrigin: '0 0', border: '7px #07A117 solid' }}></div>
            <div style={{ flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 12, display: 'inline-flex' }}>
              <div style={{ color: 'white', fontSize: 64, fontFamily: 'Poppins', fontWeight: '600', lineHeight: 96.10, letterSpacing: 1.28, wordWrap: 'break-word' }}>Our Services</div>
              <div style={{ width: 473, color: 'white', fontSize: 36, fontFamily: 'Poppins', fontWeight: '500', lineHeight: 54.05, letterSpacing: 0.72, wordWrap: 'break-word' }}>Partner with us to unlock your business's full potential.</div>
            </div>
          </div>
          <div style={{ width: 450, height: 620, left: 80, top: 530, position: 'absolute', background: 'white', boxShadow: '2px 0px 20px rgba(0, 0, 0, 0.25)', borderRadius: 12, overflow: 'hidden' }}>
            <div style={{ width: 370, left: 40, top: 330, position: 'absolute', color: 'black', fontSize: 24, fontFamily: 'Poppins', fontWeight: '400', lineHeight: 36.04, letterSpacing: 0.48, wordWrap: 'break-word' }}>Lorem ipsum dolor sit amet, consectetur adipiscing  lorem dolor sed. m dolor sit amet, consectetur adipiscing  lorem dolor sed.</div>
            <div style={{ width: 370, left: 40, top: 242, position: 'absolute', color: 'black', fontSize: 48, fontFamily: 'Poppins', fontWeight: '600', lineHeight: 72.07, letterSpacing: 0.96, wordWrap: 'break-word' }}>Service 1</div>
            <div style={{ left: 40, top: 530, position: 'absolute', justifyContent: 'flex-start', alignItems: 'center', gap: 12, display: 'inline-flex' }}>
              <div style={{ width: 172, color: '#02720D', fontSize: 28, fontFamily: 'Poppins', fontWeight: '500', lineHeight: 42.04, letterSpacing: 0.28, wordWrap: 'break-word' }}>Read  More</div>
              <div style={{ width: 28, height: 28, paddingLeft: 4.67, paddingRight: 4.67, paddingTop: 7, paddingBottom: 7, justifyContent: 'center', alignItems: 'center', display: 'flex' }}>
                <div style={{ width: 18.67, height: 14, border: '2px #02720D solid' }}></div>
              </div>
            </div>
            <div style={{ width: 147, height: 153, left: 152, top: 45, position: 'absolute' }}>
              <div style={{ width: 118.62, height: 139.88, left: 0, top: 13.12, position: 'absolute' }}>
                <div style={{ width: 59.31, height: 85.51, left: 0, top: 0, position: 'absolute', background: 'black' }}></div>
                <div style={{ width: 9.37, height: 40.05, left: 109.26, top: 45.46, position: 'absolute', background: 'black' }}></div>
                <div style={{ width: 34.72, height: 17.95, left: 24.59, top: 10.20, position: 'absolute', background: 'black' }}></div>
                <div style={{ width: 21, height: 47, left: 85.13, top: 59.46, position: 'absolute', background: 'black' }}></div>
                <div style={{ width: 16.46, height: 16.42, left: 95.35, top: 74.75, position: 'absolute', background: 'black' }}></div>
                <div style={{ width: 21, height: 47, left: 12.48, top: 59.46, position: 'absolute', background: 'black' }}></div>
                <div style={{ width: 16.46, height: 16.42, left: 6.81, top: 74.75, position: 'absolute', background: 'black' }}></div>
                <div style={{ width: 22.14, height: 16.42, left: 48.24, top: 123.45, position: 'absolute', background: 'black' }}></div>
                <div style={{ width: 38.31, height: 38.22, left: 67.82, top: 95.99, position: 'absolute', background: 'black' }}></div>
              </div>
              <div style={{ width: 90.25, height: 78.92, left: 56.75, top: 0, position: 'absolute' }}>
                <div style={{ width: 90.25, height: 78.92, left: 0, top: 0, position: 'absolute', background: 'black' }}></div>
                <div style={{ width: 52.22, height: 27.75, left: 19.02, top: 16.99, position: 'absolute' }}>
                  <div style={{ width: 19.87, height: 5.10, left: 0, top: 0, position: 'absolute', background: 'black' }}></div>
                  <div style={{ width: 52.22, height: 5.10, left: 0, top: 11.32, position: 'absolute', background: 'black' }}></div>
                  <div style={{ width: 40.30, height: 5.10, left: 0, top: 22.65, position: 'absolute', background: 'black' }}></div>
                </div>
              </div>
            </div>
          </div>
          <div style={{ width: 450, height: 620, left: 1143, top: 530, position: 'absolute', background: 'white', boxShadow: '2px 0px 20px rgba(0, 0, 0, 0.25)', borderRadius: 12, overflow: 'hidden' }}>
            <div style={{ width: 370, left: 40, top: 330, position: 'absolute', color: 'black', fontSize: 24, fontFamily: 'Poppins', fontWeight: '400', lineHeight: 36.04, letterSpacing: 0.48, wordWrap: 'break-word' }}>Lorem ipsum dolor sit amet, consectetur adipiscing  lorem dolor sed. m dolor sit amet, consectetur adipiscing  lorem dolor sed.</div>
            <div style={{ width: 370, left: 40, top: 242, position: 'absolute', color: 'black', fontSize: 48, fontFamily: 'Poppins', fontWeight: '600', lineHeight: 72.07, letterSpacing: 0.96, wordWrap: 'break-word' }}>Service 1</div>
            <div style={{ left: 40, top: 530, position: 'absolute', justifyContent: 'flex-start', alignItems: 'center', gap: 12, display: 'inline-flex' }}>
              <div style={{ width: 172, color: '#02720D', fontSize: 28, fontFamily: 'Poppins', fontWeight: '500', lineHeight: 42.04, letterSpacing: 0.28, wordWrap: 'break-word' }}>Read  More</div>
              <div style={{ width: 28, height: 28, paddingLeft: 4.67, paddingRight: 4.67, paddingTop: 7, paddingBottom: 7, justifyContent: 'center', alignItems: 'center', display: 'flex' }}>
                <div style={{ width: 18.67, height: 14, border: '2px #02720D solid' }}></div>
              </div>
            </div>
            <div style={{ width: 147, height: 153, left: 152, top: 45, position: 'absolute' }}>
              <div style={{ width: 118.62, height: 139.88, left: 0, top: 13.12, position: 'absolute' }}>
                <div style={{ width: 59.31, height: 85.51, left: 0, top: 0, position: 'absolute', background: 'black' }}></div>
                <div style={{ width: 9.37, height: 40.05, left: 109.26, top: 45.46, position: 'absolute', background: 'black' }}></div>
                <div style={{ width: 34.72, height: 17.95, left: 24.59, top: 10.20, position: 'absolute', background: 'black' }}></div>
                <div style={{ width: 21, height: 47, left: 85.13, top: 59.46, position: 'absolute', background: 'black' }}></div>
                <div style={{ width: 16.46, height: 16.42, left: 95.35, top: 74.75, position: 'absolute', background: 'black' }}></div>
                <div style={{ width: 21, height: 47, left: 12.48, top: 59.46, position: 'absolute', background: 'black' }}></div>
                <div style={{ width: 16.46, height: 16.42, left: 6.81, top: 74.75, position: 'absolute', background: 'black' }}></div>
                <div style={{ width: 22.14, height: 16.42, left: 48.24, top: 123.45, position: 'absolute', background: 'black' }}></div>
                <div style={{ width: 38.31, height: 38.22, left: 67.82, top: 95.99, position: 'absolute', background: 'black' }}></div>
              </div>
              <div style={{ width: 90.25, height: 78.92, left: 56.75, top: 0, position: 'absolute' }}>
                <div style={{ width: 90.25, height: 78.92, left: 0, top: 0, position: 'absolute', background: 'black' }}></div>
                <div style={{ width: 52.22, height: 27.75, left: 19.02, top: 16.99, position: 'absolute' }}>
                  <div style={{ width: 19.87, height: 5.10, left: 0, top: 0, position: 'absolute', background: 'black' }}></div>
                  <div style={{ width: 52.22, height: 5.10, left: 0, top: 11.32, position: 'absolute', background: 'black' }}></div>
                  <div style={{ width: 40.30, height: 5.10, left: 0, top: 22.65, position: 'absolute', background: 'black' }}></div>
                </div>
              </div>
            </div>
          </div>
          <div style={{ width: 450, height: 620, left: 612, top: 530, position: 'absolute', background: 'white', boxShadow: '2px 0px 20px rgba(0, 0, 0, 0.25)', borderRadius: 12, overflow: 'hidden' }}>
            <div style={{ width: 370, left: 40, top: 330, position: 'absolute', color: 'black', fontSize: 24, fontFamily: 'Poppins', fontWeight: '400', lineHeight: 36.04, letterSpacing: 0.48, wordWrap: 'break-word' }}>Lorem ipsum dolor sit amet, consectetur adipiscing  lorem dolor sed. m dolor sit amet, consectetur adipiscing  lorem dolor sed.</div>
            <div style={{ width: 370, left: 40, top: 242, position: 'absolute', color: 'black', fontSize: 48, fontFamily: 'Poppins', fontWeight: '600', lineHeight: 72.07, letterSpacing: 0.96, wordWrap: 'break-word' }}>Service 1</div>
            <div style={{ left: 40, top: 530, position: 'absolute', justifyContent: 'flex-start', alignItems: 'center', gap: 12, display: 'inline-flex' }}>
              <div style={{ width: 172, color: '#02720D', fontSize: 28, fontFamily: 'Poppins', fontWeight: '500', lineHeight: 42.04, letterSpacing: 0.28, wordWrap: 'break-word' }}>Read  More</div>
              <div style={{ width: 28, height: 28, paddingLeft: 4.67, paddingRight: 4.67, paddingTop: 7, paddingBottom: 7, justifyContent: 'center', alignItems: 'center', display: 'flex' }}>
                <div style={{ width: 18.67, height: 14, border: '2px #02720D solid' }}></div>
              </div>
            </div>
            <div style={{ width: 147, height: 153, left: 152, top: 45, position: 'absolute' }}>
              <div style={{ width: 118.62, height: 139.88, left: 0, top: 13.12, position: 'absolute' }}>
                <div style={{ width: 59.31, height: 85.51, left: 0, top: 0, position: 'absolute', background: 'black' }}></div>
                <div style={{ width: 9.37, height: 40.05, left: 109.26, top: 45.46, position: 'absolute', background: 'black' }}></div>
                <div style={{ width: 34.72, height: 17.95, left: 24.59, top: 10.20, position: 'absolute', background: 'black' }}></div>
                <div style={{ width: 21, height: 47, left: 85.13, top: 59.46, position: 'absolute', background: 'black' }}></div>
                <div style={{ width: 16.46, height: 16.42, left: 95.35, top: 74.75, position: 'absolute', background: 'black' }}></div>
                <div style={{ width: 21, height: 47, left: 12.48, top: 59.46, position: 'absolute', background: 'black' }}></div>
                <div style={{ width: 16.46, height: 16.42, left: 6.81, top: 74.75, position: 'absolute', background: 'black' }}></div>
                <div style={{ width: 22.14, height: 16.42, left: 48.24, top: 123.45, position: 'absolute', background: 'black' }}></div>
                <div style={{ width: 38.31, height: 38.22, left: 67.82, top: 95.99, position: 'absolute', background: 'black' }}></div>
              </div>
              <div style={{ width: 90.25, height: 78.92, left: 56.75, top: 0, position: 'absolute' }}>
                <div style={{ width: 90.25, height: 78.92, left: 0, top: 0, position: 'absolute', background: 'black' }}></div>
                <div style={{ width: 52.22, height: 27.75, left: 19.02, top: 16.99, position: 'absolute' }}>
                  <div style={{ width: 19.87, height: 5.10, left: 0, top: 0, position: 'absolute', background: 'black' }}></div>
                  <div style={{ width: 52.22, height: 5.10, left: 0, top: 11.32, position: 'absolute', background: 'black' }}></div>
                  <div style={{ width: 40.30, height: 5.10, left: 0, top: 22.65, position: 'absolute', background: 'black' }}></div>
                </div>
              </div>
            </div>
          </div>
          <div style={{ width: 450, height: 620, left: 80, top: 1291, position: 'absolute', background: 'white', boxShadow: '2px 0px 20px rgba(0, 0, 0, 0.25)', borderRadius: 12, overflow: 'hidden' }}>
            <div style={{ width: 370, left: 40, top: 330, position: 'absolute', color: 'black', fontSize: 24, fontFamily: 'Poppins', fontWeight: '400', lineHeight: 36.04, letterSpacing: 0.48, wordWrap: 'break-word' }}>Lorem ipsum dolor sit amet, consectetur adipiscing  lorem dolor sed. m dolor sit amet, consectetur adipiscing  lorem dolor sed.</div>
            <div style={{ width: 370, left: 40, top: 242, position: 'absolute', color: 'black', fontSize: 48, fontFamily: 'Poppins', fontWeight: '600', lineHeight: 72.07, letterSpacing: 0.96, wordWrap: 'break-word' }}>Service 1</div>
            <div style={{ left: 40, top: 530, position: 'absolute', justifyContent: 'flex-start', alignItems: 'center', gap: 12, display: 'inline-flex' }}>
              <div style={{ width: 172, color: '#02720D', fontSize: 28, fontFamily: 'Poppins', fontWeight: '500', lineHeight: 42.04, letterSpacing: 0.28, wordWrap: 'break-word' }}>Read  More</div>
              <div style={{ width: 28, height: 28, paddingLeft: 4.67, paddingRight: 4.67, paddingTop: 7, paddingBottom: 7, justifyContent: 'center', alignItems: 'center', display: 'flex' }}>
                <div style={{ width: 18.67, height: 14, border: '2px #02720D solid' }}></div>
              </div>
            </div>
            <div style={{ width: 147, height: 153, left: 152, top: 45, position: 'absolute' }}>
              <div style={{ width: 118.62, height: 139.88, left: 0, top: 13.12, position: 'absolute' }}>
                <div style={{ width: 59.31, height: 85.51, left: 0, top: 0, position: 'absolute', background: 'black' }}></div>
                <div style={{ width: 9.37, height: 40.05, left: 109.26, top: 45.46, position: 'absolute', background: 'black' }}></div>
                <div style={{ width: 34.72, height: 17.95, left: 24.59, top: 10.20, position: 'absolute', background: 'black' }}></div>
                <div style={{ width: 21, height: 47, left: 85.13, top: 59.46, position: 'absolute', background: 'black' }}></div>
                <div style={{ width: 16.46, height: 16.42, left: 95.35, top: 74.75, position: 'absolute', background: 'black' }}></div>
                <div style={{ width: 21, height: 47, left: 12.48, top: 59.46, position: 'absolute', background: 'black' }}></div>
                <div style={{ width: 16.46, height: 16.42, left: 6.81, top: 74.75, position: 'absolute', background: 'black' }}></div>
                <div style={{ width: 22.14, height: 16.42, left: 48.24, top: 123.45, position: 'absolute', background: 'black' }}></div>
                <div style={{ width: 38.31, height: 38.22, left: 67.82, top: 95.99, position: 'absolute', background: 'black' }}></div>
              </div>
              <div style={{ width: 90.25, height: 78.92, left: 56.75, top: 0, position: 'absolute' }}>
                <div style={{ width: 90.25, height: 78.92, left: 0, top: 0, position: 'absolute', background: 'black' }}></div>
                <div style={{ width: 52.22, height: 27.75, left: 19.02, top: 16.99, position: 'absolute' }}>
                  <div style={{ width: 19.87, height: 5.10, left: 0, top: 0, position: 'absolute', background: 'black' }}></div>
                  <div style={{ width: 52.22, height: 5.10, left: 0, top: 11.32, position: 'absolute', background: 'black' }}></div>
                  <div style={{ width: 40.30, height: 5.10, left: 0, top: 22.65, position: 'absolute', background: 'black' }}></div>
                </div>
              </div>
            </div>
          </div>
          <div style={{ width: 450, height: 620, left: 1143, top: 1291, position: 'absolute', background: 'white', boxShadow: '2px 0px 20px rgba(0, 0, 0, 0.25)', borderRadius: 12, overflow: 'hidden' }}>
            <div style={{ width: 370, left: 40, top: 330, position: 'absolute', color: 'black', fontSize: 24, fontFamily: 'Poppins', fontWeight: '400', lineHeight: 36.04, letterSpacing: 0.48, wordWrap: 'break-word' }}>Lorem ipsum dolor sit amet, consectetur adipiscing  lorem dolor sed. m dolor sit amet, consectetur adipiscing  lorem dolor sed.</div>
            <div style={{ width: 370, left: 40, top: 242, position: 'absolute', color: 'black', fontSize: 48, fontFamily: 'Poppins', fontWeight: '600', lineHeight: 72.07, letterSpacing: 0.96, wordWrap: 'break-word' }}>Service 1</div>
            <div style={{ left: 40, top: 530, position: 'absolute', justifyContent: 'flex-start', alignItems: 'center', gap: 12, display: 'inline-flex' }}>
              <div style={{ width: 172, color: '#02720D', fontSize: 28, fontFamily: 'Poppins', fontWeight: '500', lineHeight: 42.04, letterSpacing: 0.28, wordWrap: 'break-word' }}>Read  More</div>
              <div style={{ width: 28, height: 28, paddingLeft: 4.67, paddingRight: 4.67, paddingTop: 7, paddingBottom: 7, justifyContent: 'center', alignItems: 'center', display: 'flex' }}>
                <div style={{ width: 18.67, height: 14, border: '2px #02720D solid' }}></div>
              </div>
            </div>
            <div style={{ width: 147, height: 153, left: 152, top: 45, position: 'absolute' }}>
              <div style={{ width: 118.62, height: 139.88, left: 0, top: 13.12, position: 'absolute' }}>
                <div style={{ width: 59.31, height: 85.51, left: 0, top: 0, position: 'absolute', background: 'black' }}></div>
                <div style={{ width: 9.37, height: 40.05, left: 109.26, top: 45.46, position: 'absolute', background: 'black' }}></div>
                <div style={{ width: 34.72, height: 17.95, left: 24.59, top: 10.20, position: 'absolute', background: 'black' }}></div>
                <div style={{ width: 21, height: 47, left: 85.13, top: 59.46, position: 'absolute', background: 'black' }}></div>
                <div style={{ width: 16.46, height: 16.42, left: 95.35, top: 74.75, position: 'absolute', background: 'black' }}></div>
                <div style={{ width: 21, height: 47, left: 12.48, top: 59.46, position: 'absolute', background: 'black' }}></div>
                <div style={{ width: 16.46, height: 16.42, left: 6.81, top: 74.75, position: 'absolute', background: 'black' }}></div>
                <div style={{ width: 22.14, height: 16.42, left: 48.24, top: 123.45, position: 'absolute', background: 'black' }}></div>
                <div style={{ width: 38.31, height: 38.22, left: 67.82, top: 95.99, position: 'absolute', background: 'black' }}></div>
              </div>
              <div style={{ width: 90.25, height: 78.92, left: 56.75, top: 0, position: 'absolute' }}>
                <div style={{ width: 90.25, height: 78.92, left: 0, top: 0, position: 'absolute', background: 'black' }}></div>
                <div style={{ width: 52.22, height: 27.75, left: 19.02, top: 16.99, position: 'absolute' }}>
                  <div style={{ width: 19.87, height: 5.10, left: 0, top: 0, position: 'absolute', background: 'black' }}></div>
                  <div style={{ width: 52.22, height: 5.10, left: 0, top: 11.32, position: 'absolute', background: 'black' }}></div>
                  <div style={{ width: 40.30, height: 5.10, left: 0, top: 22.65, position: 'absolute', background: 'black' }}></div>
                </div>
              </div>
            </div>
          </div>
          <div style={{ width: 450, height: 620, left: 612, top: 1291, position: 'absolute', background: 'white', boxShadow: '2px 0px 20px rgba(0, 0, 0, 0.25)', borderRadius: 12, overflow: 'hidden' }}>
            <div style={{ width: 370, left: 40, top: 330, position: 'absolute', color: 'black', fontSize: 24, fontFamily: 'Poppins', fontWeight: '400', lineHeight: 36.04, letterSpacing: 0.48, wordWrap: 'break-word' }}>Lorem ipsum dolor sit amet, consectetur adipiscing  lorem dolor sed. m dolor sit amet, consectetur adipiscing  lorem dolor sed.</div>
            <div style={{ width: 370, left: 40, top: 242, position: 'absolute', color: 'black', fontSize: 48, fontFamily: 'Poppins', fontWeight: '600', lineHeight: 72.07, letterSpacing: 0.96, wordWrap: 'break-word' }}>Service 1</div>
            <div style={{ left: 40, top: 530, position: 'absolute', justifyContent: 'flex-start', alignItems: 'center', gap: 12, display: 'inline-flex' }}>
              <div style={{ width: 172, color: '#02720D', fontSize: 28, fontFamily: 'Poppins', fontWeight: '500', lineHeight: 42.04, letterSpacing: 0.28, wordWrap: 'break-word' }}>Read  More</div>
              <div style={{ width: 28, height: 28, paddingLeft: 4.67, paddingRight: 4.67, paddingTop: 7, paddingBottom: 7, justifyContent: 'center', alignItems: 'center', display: 'flex' }}>
                <div style={{ width: 18.67, height: 14, border: '2px #02720D solid' }}></div>
              </div>
            </div>
            <div style={{ width: 147, height: 153, left: 152, top: 45, position: 'absolute' }}>
              <div style={{ width: 118.62, height: 139.88, left: 0, top: 13.12, position: 'absolute' }}>
                <div style={{ width: 59.31, height: 85.51, left: 0, top: 0, position: 'absolute', background: 'black' }}></div>
                <div style={{ width: 9.37, height: 40.05, left: 109.26, top: 45.46, position: 'absolute', background: 'black' }}></div>
                <div style={{ width: 34.72, height: 17.95, left: 24.59, top: 10.20, position: 'absolute', background: 'black' }}></div>
                <div style={{ width: 21, height: 47, left: 85.13, top: 59.46, position: 'absolute', background: 'black' }}></div>
                <div style={{ width: 16.46, height: 16.42, left: 95.35, top: 74.75, position: 'absolute', background: 'black' }}></div>
                <div style={{ width: 21, height: 47, left: 12.48, top: 59.46, position: 'absolute', background: 'black' }}></div>
                <div style={{ width: 16.46, height: 16.42, left: 6.81, top: 74.75, position: 'absolute', background: 'black' }}></div>
                <div style={{ width: 22.14, height: 16.42, left: 48.24, top: 123.45, position: 'absolute', background: 'black' }}></div>
                <div style={{ width: 38.31, height: 38.22, left: 67.82, top: 95.99, position: 'absolute', background: 'black' }}></div>
              </div>
              <div style={{ width: 90.25, height: 78.92, left: 56.75, top: 0, position: 'absolute' }}>
                <div style={{ width: 90.25, height: 78.92, left: 0, top: 0, position: 'absolute', background: 'black' }}></div>
                <div style={{ width: 52.22, height: 27.75, left: 19.02, top: 16.99, position: 'absolute' }}>
                  <div style={{ width: 19.87, height: 5.10, left: 0, top: 0, position: 'absolute', background: 'black' }}></div>
                  <div style={{ width: 52.22, height: 5.10, left: 0, top: 11.32, position: 'absolute', background: 'black' }}></div>
                  <div style={{ width: 40.30, height: 5.10, left: 0, top: 22.65, position: 'absolute', background: 'black' }}></div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div style={{ paddingTop: 90, paddingBottom: 90, paddingLeft: 49, paddingRight: 48, background: '#007E33', borderRadius: 16, overflow: 'hidden', justifyContent: 'center', alignItems: 'center', gap: 27, display: 'inline-flex' }}>
          <div style={{ alignSelf: 'stretch', justifyContent: 'flex-start', alignItems: 'center', gap: 32, display: 'inline-flex' }}>
            <div style={{ height: 120, paddingTop: 9.43, paddingBottom: 15, paddingLeft: 10, paddingRight: 10, justifyContent: 'center', alignItems: 'center', display: 'flex' }}>
              <div style={{ width: 100, height: 95.57, border: '6px white solid' }}></div>
            </div>
            <div style={{ width: 567, color: 'white', fontSize: 28, fontFamily: 'Montserrat', fontWeight: '600', lineHeight: 47.60, wordWrap: 'break-word' }}>Subscribe to our newsletter to get latest updates</div>
          </div>
          <div style={{ width: 670, height: 56, position: 'relative' }}>
            <div style={{ width: 670, height: 56, left: 0, top: 0, position: 'absolute', background: 'white', boxShadow: '2px 0px 10px rgba(0, 0, 0, 0.25)', borderRadius: 12, border: '1px #BDBDBD solid' }} />
            <div style={{ width: 159, height: 56, left: 511, top: 0, position: 'absolute', background: 'black', boxShadow: '2px 0px 10px rgba(0, 0, 0, 0.25)', borderRadius: 12 }} />
            <div style={{ left: 24, top: 14, position: 'absolute', color: '#444444', fontSize: 18, fontFamily: 'Poppins', fontWeight: '400', wordWrap: 'break-word' }}>Enter Email Address</div>
            <div style={{ left: 568, top: 14, position: 'absolute', color: 'white', fontSize: 18, fontFamily: 'Poppins', fontWeight: '400', wordWrap: 'break-word' }}>Enter</div>
          </div>
        </div>
        <div style={{ width: 1940, paddingLeft: 343, paddingRight: 343, paddingTop: 120, paddingBottom: 120, background: 'white', justifyContent: 'center', alignItems: 'center', gap: 120, display: 'inline-flex' }}>
          <div style={{ flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 12, display: 'inline-flex' }}>
            <div style={{ flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 10, display: 'flex' }}>
              <div style={{ textAlign: 'center', color: '#007E33', fontSize: 24, fontFamily: 'Inter', fontWeight: '600', lineHeight: 40.80, wordWrap: 'break-word' }}>Our Links</div>
            </div>
            <div style={{ flexDirection: 'column', justifyContent: 'center', alignItems: 'flex-start', gap: 10, display: 'flex' }}>
              <div style={{ color: 'black', fontSize: 24.39, fontFamily: 'Inter', fontWeight: '400', lineHeight: 41.46, wordWrap: 'break-word' }}>About Us<br />Services<br />Team<br />Contact Us</div>
            </div>
          </div>
          <div style={{ flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 12, display: 'inline-flex' }}>
            <div style={{ justifyContent: 'flex-start', alignItems: 'flex-start', gap: 10, display: 'inline-flex' }}>
              <div style={{ width: 103.64, height: 41.66, textAlign: 'center', color: '#007E33', fontSize: 24.39, fontFamily: 'Inter', fontWeight: '600', lineHeight: 41.46, wordWrap: 'break-word' }}>Services<br /><br /></div>
            </div>
            <div style={{ justifyContent: 'flex-start', alignItems: 'flex-start', gap: 10, display: 'inline-flex' }}>
              <div style={{ color: 'black', fontSize: 24.39, fontFamily: 'Inter', fontWeight: '400', lineHeight: 41.46, wordWrap: 'break-word' }}>Product<br />Advisory Consulting<br />Professional Services</div>
            </div>
          </div>
          <div style={{ flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 12, display: 'inline-flex' }}>
            <div style={{ justifyContent: 'flex-start', alignItems: 'flex-start', gap: 10, display: 'inline-flex' }}>
              <div style={{ width: 145.30, height: 41.66, textAlign: 'center', color: '#007E33', fontSize: 24.39, fontFamily: 'Inter', fontWeight: '600', lineHeight: 41.46, wordWrap: 'break-word' }}>Other Links<br /><br /></div>
            </div>
            <div style={{ justifyContent: 'flex-start', alignItems: 'flex-start', gap: 10, display: 'inline-flex' }}>
              <div style={{ color: 'black', fontSize: 24.39, fontFamily: 'Inter', fontWeight: '400', lineHeight: 41.46, wordWrap: 'break-word' }}>Privacy Policy<br />Terms & Condition</div>
            </div>
          </div>
          <div style={{ flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'flex-start', gap: 12, display: 'inline-flex' }}>
            <div style={{ width: 145.30, height: 41.66, color: '#007E33', fontSize: 24.39, fontFamily: 'Inter', fontWeight: '600', lineHeight: 41.46, wordWrap: 'break-word' }}>Follow Us :</div>
            <div style={{ paddingRight: 4.06, justifyContent: 'center', alignItems: 'center', gap: 26.42, display: 'inline-flex' }}>
              <div style={{ width: 41.66, height: 29.47, position: 'relative' }}>
                <div style={{ width: 41.66, height: 29.35, left: 0, top: 0, position: 'absolute', background: '#FF0000' }}></div>
                <div style={{ width: 10.79, height: 12.58, left: 16.66, top: 8.39, position: 'absolute', background: 'white' }}></div>
              </div>
              <div style={{ width: 38.61, height: 38.61, justifyContent: 'center', alignItems: 'center', display: 'flex' }}>
                <div style={{ width: 38.61, height: 38.61, position: 'relative' }}>
                  <div style={{ width: 38.61, height: 38.61, left: 0, top: 0, position: 'absolute', background: 'white' }}></div>
                  <div style={{ width: 38.61, height: 38.61, left: 0, top: 0, position: 'absolute', background: '#0A66C2' }}></div>
                  <div style={{ width: 27.15, height: 27.10, left: 5.73, top: 5.73, position: 'absolute', background: 'white' }}></div>
                </div>
              </div>
              <div style={{ width: 40.64, height: 40.64, position: 'relative' }}>
                <div style={{ width: 40.64, height: 40.40, left: -0, top: 0, position: 'absolute', background: '#1877F2' }}></div>
                <div style={{ width: 17.38, height: 32.70, left: 11.98, top: 7.94, position: 'absolute', background: 'white' }}></div>
              </div>
              <div style={{ width: 41.66, height: 41.66, justifyContent: 'center', alignItems: 'center', display: 'flex' }}>
                <div style={{ width: 41.66, height: 41.66, position: 'relative' }}>
                  <div style={{ width: 41.66, height: 41.66, left: 0, top: 0, position: 'absolute', background: 'radial-gradient(50.45% 54.24% at 106.23% 76.35%, #FFDD55 0%, #FFDD55 10%, #FF543E 50%, #C837AB 100%)' }}></div>
                  <div style={{ width: 41.66, height: 41.66, left: 0, top: 0, position: 'absolute', background: 'radial-gradient(112.86% 27.38% at -401.33% 20.69%, #3771C8 0%, #3771C8 13%, rgba(102, 0, 255, 0) 100%)' }}></div>
                  <div style={{ width: 32.55, height: 32.55, left: 4.56, top: 4.55, position: 'absolute', background: 'white' }}></div>
                </div>
              </div>
              <div style={{ width: 32.51, height: 32.51, paddingTop: 2.03, paddingBottom: 2.03, paddingLeft: 2.43, paddingRight: 2.44, justifyContent: 'center', alignItems: 'center', display: 'flex' }}>
                <div style={{ width: 27.64, height: 28.45, background: 'white' }}></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>

  )
}

export default Home
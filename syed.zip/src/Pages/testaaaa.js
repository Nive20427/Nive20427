const services = [
    {
        id: 1,
        title: "Service 1",
        description: "Lorem ipsum dolor sit amet, consectetur adipiscing lorem dolor sed. m dolor sit amet, consectetur adipiscing lorem dolor sed.",
        icon: "service-icon.png"
    },
    {
        id: 2,
        title: "Service 1",
        description: "Lorem ipsum dolor sit amet, consectetur adipiscing lorem dolor sed. m dolor sit amet, consectetur adipiscing lorem dolor sed.",
        icon: "service-icon.png"
    },
    {
        id: 3,
        title: "Service 1",
        description: "Lorem ipsum dolor sit amet, consectetur adipiscing lorem dolor sed. m dolor sit amet, consectetur adipiscing lorem dolor sed.",
        icon: "service-icon.png"
    },
    {
        id: 4,
        title: "Service 1",
        description: "Lorem ipsum dolor sit amet, consectetur adipiscing lorem dolor sed. m dolor sit amet, consectetur adipiscing lorem dolor sed.",
        icon: "service-icon.png"
    },
    {
        id: 5,
        title: "Service 1",
        description: "Lorem ipsum dolor sit amet, consectetur adipiscing lorem dolor sed. m dolor sit amet, consectetur adipiscing lorem dolor sed.",
        icon: "service-icon.png"
    },
    {
        id: 6,
        title: "Service 1",
        description: "Lorem ipsum dolor sit amet, consectetur adipiscing lorem dolor sed. m dolor sit amet, consectetur adipiscing lorem dolor sed.",
        icon: "service-icon.png"
    }
];

export default function Appaa ()  {
    const  handleProductClick = (e) => {
        e.preventDefault();
        window.location.href = "/product"; // Replace with the actual landing page URL
    };

    return (
        <div>
            <nav>
                <a href="/">Home</a>
                <a href="/about">About Us</a>
                <a href="/services">Services</a>
                <div className="dropdown">
                    <a href="/product" onClick={handleProductClick}>Product</a>
                    <div className="dropdown-content">
                        <a href="/product/feature1">Feature 1</a>
                        <a href="/product/feature2">Feature 2</a>
                        <a href="/product/feature3">Feature 3</a>
                    </div>
                </div>
                <a href="/contact">Contact</a>
            </nav>
            <header>
                <h1>Transform Your Business with RapidQube</h1>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur at massa a nulla luctus vehicula.</p>
                <button>Get Started</button>
                <button>Learn More</button>
            </header>
            <div className="services-section">
                <div className="services-header">
                    <h2>Our Services</h2>
                    <p>Partner with us to unlock your business's full potential.</p>
                </div>
                <div className="services-description">
                    <p>Lorem ipsum dolor sit amet, consectetur git adipiscing lorem dolor sed. m dolor sit amet, consectetur adipiscing lorem dolor sed. ipsum dolor sit amet, consectetur adipiscing lorem d</p>
                </div>
                <div className="services-cards">
                    {services.map(service => (
                        <div className="service-card" key={service.id}>git init
                            <img src={service.icon} alt={`${service.title} Icon`} />git 
                            <h3>{service.title}</h3>
                            <p>{service.description}</p>
                            <a href="#" className="read-more">Read More <span>→</span></a>
                        </div>
                    ))}
                </div>
            </div>
            <div className="newsletter-section">
                <p>Subscribe to our newsletter to get latest updates</p>
                <input type="email" placeholder="Enter Email Address" />
                <button>Enter</button>
            </div>
        </div>
    );
}


// import { Check } from '@mui/icons-material';
import React, { useState } from 'react'

function IsprimeorNot() {
    const [valNum, setvalNum] = useState("")

    function isPrime(num) {
        let res = true;
        if (num <= 1) {
            res = false;
        }
        for (let i = 2; i * i <= num; i++) {
            if (num % i === 0) {
                res = false;
                break;
            }
        }
        if (res) {
            console.log(num, " is a prime number.");
        }
        else {
            console.log(num, " is not a prime number.");
        }// If no divisors were found, num is a prime number    
    }
    const handleInputChange = (e) => {
        console.log("asd");

        setvalNum(e.target.value)
    }
    const buttonClick = () => {
        let res = isPrime(valNum)
        console.log(res)
    }

    return (
        <div className="primediv">

            <p>IsprimeorNot</p>

            <input value={valNum} onChange={(e) => handleInputChange(e)} />

            <button name='Check' value={"Clicks"} onClick={() => buttonClick()}>Check</button>



        </div>
    )
}

export default IsprimeorNot
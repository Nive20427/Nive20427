import React, { useState } from 'react'

function IsPrimeINRange() {
    const [start, setStart] = useState()
    const [end, setEnd] = useState()

    const handleInputStart = (e) => {
        
        let val = e.target.value

        setStart(val)
    }
    const handleInputend = (e) => {
        
        let val = e.target.value


        setEnd(val)
    }
    const buttonClick = () => {
        // let res 
        let primes = [];

        for (let i = start; i <= end; i++) {
            console.log("primes",start,end)

            if (isPrime(i)) {
                console.log("primes",start,end,i)

                primes.push(i);

            }

        }
 console.log("primes",primes)
        return primes;
        // console.log(res)
    }
    function isPrime(num) {
        console.log("primes",num)
        let res = true;
        if (num <= 1) {
            res = false;
        }
        for (let i = 2; i * i <= num; i++) {
            if (num % i === 0) {
                res = false;
                break;
            }
        }
        if (res) {
            return true;
        }
        else {
            return false;
        }
       
        
    }


    return (<>
        <div>IsPrimeINRange</div>


        <input value={start} onChange={(e) => handleInputStart(e)} />
        <input value={end}  onChange={(e) => handleInputend(e)} />


        <button name='Check' value={"Clicks"} onClick={() => buttonClick()}>Check</button>



    </>
    )
}

export default IsPrimeINRange
import * as React from "react";
import Rating from "@mui/material/Rating";
import Typography from "@mui/material/Typography";
import SentimentVeryDissatisfiedIcon from "@mui/icons-material/SentimentVeryDissatisfied";
import SentimentDissatisfiedIcon from "@mui/icons-material/SentimentDissatisfied";
import SentimentSatisfiedIcon from "@mui/icons-material/SentimentSatisfied";
import SentimentSatisfiedAltIcon from "@mui/icons-material/SentimentSatisfiedAltOutlined";
import SentimentVerySatisfiedIcon from "@mui/icons-material/SentimentVerySatisfied";

const customStyle = {
  "& css-1c99szj-MuiRating-icon ": {
    color: "white !important",
    //border:"4px Red"
  },
  "& .MuiRating-iconHover": {
    color: "purple"
  },
  "& .MuiRating-decimal:hover": {
    transform: "scale(2.5)"
  }
};

export default function CustomRating() {
  const [selectedValue, setSelectedValue] = React.useState(4.8);
  const [icon, setIcon] = React.useState(<SentimentVerySatisfiedIcon />);
  const [emptyIcon, setEmptyIcon] = React.useState(
    <SentimentVerySatisfiedIcon />
  );

  React.useEffect(() => {
    if (selectedValue <= 1) {
      setIcon(<SentimentVeryDissatisfiedIcon />);
      setEmptyIcon(<SentimentVeryDissatisfiedIcon />);
    } else if (selectedValue <= 2) {
      setIcon(<SentimentDissatisfiedIcon />);
      setEmptyIcon(<SentimentDissatisfiedIcon />);
    } else if (selectedValue <= 3) {
      setIcon(<SentimentSatisfiedIcon />);
      setEmptyIcon(<SentimentSatisfiedIcon />);
    } else if (selectedValue <= 3) {
      setIcon(<SentimentSatisfiedAltIcon />);
      setEmptyIcon(<SentimentSatisfiedAltIcon />);
    } else {
      setIcon(<SentimentVerySatisfiedIcon />);
      setEmptyIcon(<SentimentVerySatisfiedIcon />);
    }
  }, [selectedValue]);

  return (
    <>
      <Typography>Icon Changes Based On Rating</Typography>
     <div style={{background:"black"}}> <Rating 
      name="rating"
      defaultValue={selectedValue}
      emptyIcon={emptyIcon}
      icon={icon}
      style={customStyle}/></div>
    </>
  );
}
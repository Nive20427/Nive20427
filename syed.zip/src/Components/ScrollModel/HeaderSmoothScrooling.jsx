import React from 'react'

function HeaderSmoothScrooling() {
    return (
        <div>
            <div className='d-flex flex-row'>
                <h1>Contents</h1>
                <a href='#Pizza'>Pizza</a>
                <a href='#Burger'>Burger</a>
                <a href='#Sandwich'>Sandwich</a>
                <a href='#Borotta'>Borotta</a>

            </div>
            <div>
                <p>
                    <h3 id='Pizza'> Pizza</h3>
                    <p>Pizza (/ˈpiːtsə/ PEET-sə, Italian: [ˈpittsa]; Neapolitan: [ˈpittsə]) is a dish of Italian origin consisting of a usually round,
                        flat base of leavened wheat-based dough topped with tomatoes, cheese, and often various other ingredients
                        (such as anchovies, mushrooms, onions, olives, vegetables, meat, etc.),
                        which is then baked at a high temperature, traditionally in a wood-fired oven.[1]</p>
                </p>
                <p>
                    <h3 id='Burger'>Burger</h3>
                    <p>A hamburger or simply burger is a food consisting of fillings—usually a patty of ground meat,
                        typically beef—placed inside a sliced bun or bread roll. Hamburgers are often served with cheese,
                        lettuce, tomato, onion, pickles, bacon, or chilis; condiments such as ketchup, mustard, mayonnaise, relish, or a "special sauce",
                        often a variation of Thousand Island dressing; and are frequently placed on sesame seed buns.
                        A hamburger patty topped with cheese is called a cheeseburger.[1]</p>
                </p>
                <p>
                    <h3 id='Sandwich'>Sandwich</h3>
                    <p>A sandwich is a food typically consisting of vegetables, sliced cheese or meat, placed on or between slices of bread, or more
                        generally any dish wherein bread serves as a container or wrapper for another food type.[1][2][3]
                        The sandwich began as a portable, convenient finger food in the Western world, though over time it has become prevalent worldwide.</p>
                </p>
                <p>
                    <h3 id='Borotta'>Borotta</h3>
                    <p>Parotta or Porotta is a layered Indian and Sri Lankan flatbread made from Maida or Atta,
                        alternatively known as flaky ribbon pancake.
                        It is very common in the Indian states of Kerala and Tamil Nadu and
                        widely available in other states like Karnataka and Maharashtra and countries like Malaysia,
                        the United Arab Emirates and Sri Lanka.</p>
                </p>

            </div>
        </div>
    )
}

export default HeaderSmoothScrooling
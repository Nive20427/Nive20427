import React, { useContext, useState } from 'react';
export default function ParentWithoutContext() {
    const [user, setUser] = useState("React")
    return (<>
        <h1>parent  component </h1>
        <Child1 user={user} />
    </>);
}

 function Child1({ user }) {
    return (<>
        <h1>Child 1 component </h1>
        <Child2 user={user} />
    </>);
}
 function Child2({ user }) {
    return (<>
        <h1>Child 2 component </h1>
        <Child3 user={user} />

    </>);
}

 function Child3({ user }) {
    return (<>
        <h1>Child 3 component </h1>
        <Child4 user={user} />

    </>);
}
 function Child4({ user }) {
    return (<>
        <h1>Child 4 component </h1>
        <Child5 user={user} />

    </>);
}
 function Child5({ user }) {
    return (<>
        <h1>Child 5 component </h1>
        <h3>{user} is a library</h3>
    </>);
}

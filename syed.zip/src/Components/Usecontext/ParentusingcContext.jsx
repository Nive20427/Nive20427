import React, { createContext, useContext, useState } from 'react';

const UserContext = createContext();

export default function ParentsWithContext() {
    const [user, setUser] = useState("React");

    return (
        <UserContext.Provider value={user}>
            <h1>parent component</h1>
            <Child1 />
        </UserContext.Provider>
    );
}

function Child1() {
    return (
        <>
            <h1>Child 1 component</h1>
            <Child2 />
        </>
    );
}

function Child2() {
    return (
        <>
            <h1>Child 2 component</h1>
            <Child3 />
        </>
    );
}

function Child3() {
    return (
        <>
            <h1>Child 3 component</h1>
            <Child4 />
        </>
    );
}

function Child4() {
    return (
        <>
            <h1>Child 4 component</h1>
            <Child5 />
        </>
    );
}

function Child5() {
    const user = useContext(UserContext);

    return (
        <>
            <h1>Child 5 component</h1>
            <h3>{user} is a library</h3>
        </>
    );
}
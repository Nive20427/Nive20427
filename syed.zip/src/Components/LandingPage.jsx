import React from 'react';
import NavBar from './NavBar/NavBar';



function Landingpage() {
    return ( <>
    {/* <NavBar/> */}
    </> );
}

export default Landingpage;
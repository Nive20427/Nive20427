import { Input } from 'antd';
import React, { useEffect, useState } from 'react';


function Inputincrementer() {
    var finalArray = []
    var array = [];

    const [userCount, setUserCount] = useState()
    const [userValue, setUserValue] = useState()
    const [mainSet, setmainSet] = useState([])
    const [mainSet1, setmainSet1] = useState([])
    console.log("asf", mainSet1)


    const handleChange = (e) => {
        let val = e.target.value
        let arr = []

        setUserValue(val)

        // sethandle()
    }

    const sethandle = () => {

    }

    useEffect(() => {
        var j = 0
        console.log("asdddd", userValue);
        setmainSet(userValue)
        finalArray = Array(userValue).fill(j + 1)
        // mainSet.push(userValue)
        array = [];
        for (var i = 0; i < userValue; ++i) array.push(j + 1);
        console.log("asf", mainSet, array, finalArray)
        setmainSet1([array])
    }, [userValue])


    console.log("asf", mainSet, array, finalArray, mainSet1)

    return (<>

        <input value={userCount} onChange={(e) => handleChange(e)} />
        {/* 
        {userValue!==undefined&&userValue.length !== 0 && userValue.map((i, id) => {
            console.log("asddf", i, id);
        })
        } */}
        {mainSet1 !== undefined && mainSet1.length !== 0 && mainSet1.map((i, id) => (
            // console.log("asd 2321", i
            // <p>{i}</p>
            <h1>{i}</h1>
        ))}
        {/* {mainSet!==undefined&& mainSet. } */}
    </>);
}

export default Inputincrementer;
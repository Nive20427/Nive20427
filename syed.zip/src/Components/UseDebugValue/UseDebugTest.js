import { useDebugValue, useState } from "react";
 
function useCount() {
    const [count, setCount] = useState(0);
 
    setInterval(() => {
        setCount(count + 1);
    }, 2000);
 
    useDebugValue(count);
    return count;
}
 
function UseDebugTest() {
    const count = useCount();
 
    return (
        <div className="App">
            <button>{count}</button>
        </div>
    );
}
 
export default UseDebugTest;
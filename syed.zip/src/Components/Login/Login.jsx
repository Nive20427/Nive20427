import Checkbox from 'antd/es/checkbox/Checkbox';
import Form from 'antd/es/form/Form';
import Input from 'antd/es/input/Input';
import { Button } from 'antd/es/radio';
import React, { Component } from 'react';


import { useState, useEffect } from "react";
// import ReactDOM from "react-dom/client";

export default function Login() {
    const [click, setClick] = useState()
    const [count, setCount] = useState(0);

    useEffect(() => {
        // setTimeout(() => {
            setCount((count) => count + 1);
        // });
    }, [click]);

    const handleClick = (e) => {
        setClick(e)
    }
    return (<>
        <button name="add" value={"add"} onClick={(e) => handleClick(e)}>add</button>
        <h1>I have rendered {count} times!</h1>;
    </>)

}
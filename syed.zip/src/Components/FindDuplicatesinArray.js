// if(false.toString()==='false'){

//     console.log("1")
// }else{
//     console.log("2");
// }


let arr = [1, 2, 3, 4, 2, 7, 8, 8, 3];


function duplicate() {
    
    let newArr = [];
    let index = 0;
   /*Using ForLoop By Own*/
   /*--------------------*/
    // for (let i = 0; i < arr.length; i++) {
    //     // console.log("1",i,arr);
    //     for (let j = i + 1; j < arr.length; j++) {
    //     // console.log("j",j,arr[j]);
            
    //         if (arr[i] == arr[j]) {
    //             console.log(arr[j]);
    //         } else {
    //             // break;
    //         }
    //     }
        
    // }
   /*Using ForLoop By Net*/
   /*--------------------*/
    for (let i = 0; i < arr.length - 1; i++) {
        for (let j = i + 1; j < arr.length; j++) {
        if (arr[i] === arr[j]) {
              newArr[index] = arr[i];
              index++;
           }
        }
     }
     return newArr;



}


     let data = arr.filter((currentValue, currentIndex) =>
    arr.indexOf(currentValue) !== currentIndex);

    console.log("daa",data);
  

console.log(duplicate())
// console.log(findDuplicates())

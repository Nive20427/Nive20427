import React, { Component } from 'react';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { routes } from '../routes/route';
import Landingpage from './LandingPage';
import Login from './Login/Login';
import About from './About';
import MainLandingPage from './MainLandingPage';
import NavBar from './NavBar/NavBar';



function HomeComponent() {
    return (
        <>
      
            <BrowserRouter>

                <Routes>
                    <Route path={"/"} Component={MainLandingPage} />
                    <Route path={"/About"} Component={About} />

                    <Route path={"/login"} Component={Login} />

                </Routes>
            </BrowserRouter>




        </>
    );
}

export default HomeComponent;
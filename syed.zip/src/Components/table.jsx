

  
//   import React from "react";
// //   import "antd/dist/antd.css";
// //   import "./index.css";
//   import { Table } from "antd";
// //   import type { ColumnsType } from "antd/es/table";
// //   import "./table.less";
  
// //   interface DataType {
// //     key: string;
// //     person: string;
// //     place: string;
// //     thing: string;
// //   }
  
//   const columns= [
//     {
//       title: "Row",
//       dataIndex: "key",
//       width: 150,
//       key: "key"
//     },
//     {
//       title: "Person",
//       dataIndex: "person",
//       key: "person",
//       width: "10rem"
//     },
//     {
//       title: "Place",
//       dataIndex: "place",
//       key: "place"
//     },
//     {
//       title: "Thing",
//       dataIndex: "thing",
//       key: "thing",
//       width: "20%"
//     }
//   ];
  
//   const data  = [
//     {
//       key: "1",
//       person: "Jon",
//       place: "Beach",
//       thing: "Shovel"
//     },
//     {
//       key: "2",
//       person: "Jane",
//       place: "Airport",
//       thing: "Plane"
//     },
//     {
//       key: "3",
//       person: "Jennifer",
//       place: "Hotel",
//       thing: "Elevator"
//     },
//     {
//       key: "4",
//       person: "Dave",
//       place: "Restaurant",
//       thing: "Food"
//     },
//     {
//       key: "5",
//       person: "Jose",
//       place: "Park",
//       thing: "Dog"
//     },
//     {
//       key: "6",
//       person: "Anne",
//       place: "Disco",
//       thing: "Shoes"
//     }
//   ];
  
//   const CustomTable = () => {
//     return (
//       <Table
//         columns={columns}
//         dataSource={data}
//         onRow={(record, index) => {
//           return {
//             onClick: (event) => {
//               //console.log(record);
//              style: { background:   "green" }
//             }
//           };
//         }}
//       />
//     );
//   };
  
//   export default CustomTable;
import React, { useState } from 'react'

function MainLandingPage() {
  const [editMode, setEditmode] = useState(false)
  const [users] = useState[
    {
      "name": "asd",
      "email": "asd@gamila.comn"
    }
  ]

  const handleEdit = () => {
    setEditmode(true)
  }
  const handleEditableValues = () => {
    // setEditmode(true)
  }
  return (
    <div>

      
      
      
      <table>
      <tr>
        <th>Heading</th>
        <th></th></tr>
      <tr>
        {editMode ? <input onChange={handleEditableValues}></input> : <td>data</td>}
        <button onClick={handleEdit()}>Edit</button>
      </tr>
    </table></div>

  )
}

export default MainLandingPage
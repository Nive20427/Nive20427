// import React from 'react'
// import {
//     createBrowserRouter,
//     RouterProvider,
//     Route,
//     Link,
//   } from "react-router-dom";

// const Route = createBrowserRouter( {
   
//     createRoutesFromElements( 
//         <Route path="/" element={<Root />}>
//     )

  
// })

// export default Route
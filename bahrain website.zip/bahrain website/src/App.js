import React, { useState } from 'react';
import './App.css';
import { Routes, Route, NavLink, useNavigate } from 'react-router-dom';
import Home from './Components/Home';
import ListforCompanylogo from './Components/ListforCompanylogo';
import ProductIntro from './Components/ProductIntro';
import HomeaboutIntro from './Components/HomeaboutIntro';
import Testimonials from './Components/Testimonials';
import BusinessSolutions from './Components/BusinessSolutions';
import HomeFooter from './Components/HomeFooter';
import ProductLandingpage from './Components/Products/ProductLandingpage';
import AboutUs from './Components/About/AboutUs';
import Services from './Components/Services/Services';



function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isProductsDropdownOpen, setIsProductsDropdownOpen] = useState(false);
  const [isServicesDropdownOpen, setIsServicesDropdownOpen] = useState(false);
 
  const Navigate =useNavigate();


  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };
  const toggleProductsDropdown = () => {
    // setIsProductsDropdownOpen(!isProductsDropdownOpen);
 console.log("product hiitn=i=");
    Navigate('/product'); 
  };

  const toggleServicesDropdown = () => {
    setIsServicesDropdownOpen(!isServicesDropdownOpen);
  };

  return (
    <div className='App'>
      <header className='header bg-dark text-light py-3 sticky-top'>
        <div className="container-fluid">
          <div className="row align-items-center">
            <div className="col-md-3 logo-container">
              <div className="logo">
                <h1 className="logo-main">RapidQube</h1>
                <p className="logo-tagline">Transforming Business Paradigms</p>
              </div>
            </div>
            <div className="col-md-9">
              <nav className=''>
                <ul className='nav justify-content-end nav-section'>
                  <li className='nav-item'>
                    <NavLink to="/" className="nav-link" activeClassName="active">
                      HOME
                    </NavLink>
                  </li>
                  <li className='nav-item dropdown'>
                    <a
                     className="nav-link dropdown-toggle " 
                     onClick={toggleProductsDropdown}
                     activeClassName="active">
                      PRODUCTS
                    </a>
                    {isProductsDropdownOpen && (
                      <ul className='dropdown-menu'>
                        <li><NavLink to="/r-Suite " className="dropdown-item">R/Suite </NavLink></li>
                        <li><NavLink to="/DocT" className="dropdown-item">DocT</NavLink></li>
                        <li><NavLink to="/Rapideverse" className="dropdown-item">Rapideverse</NavLink></li>
                        <li><NavLink to="/Talkify" className="dropdown-item">Talkify</NavLink></li>
                        <li><NavLink to="/r-Mart" className="dropdown-item">R/Mart</NavLink></li>
                        <li><NavLink to="/Rapid-Property" className="dropdown-item">Rapid Property</NavLink></li>
                        <li><NavLink to="/Rapid HER" className="dropdown-item">Rapid HER</NavLink></li>
                        <li><NavLink to="/Rapid Token" className="dropdown-item">Rapid Token</NavLink></li>
                        <li><NavLink to="/QubeSphere" className="dropdown-item">QubeSphere</NavLink></li>
                        <li><NavLink to="/e/FanEng" className="dropdown-item">e/FanEng</NavLink></li>

                      </ul>
                    )}
                  </li>
                  <li className='nav-item dropdown'>
                    <NavLink to="/services" 
                    className="nav-link dropdown"
                    onClick={toggleServicesDropdown}
                     activeClassName="active">
                    SERVICES
                    </NavLink>
                    {isServicesDropdownOpen && (
                      <ul className='dropdown-menu'>
                        <li><NavLink to="/service1" className="dropdown-item">Service 1</NavLink></li>
                        <li><NavLink to="/service2" className="dropdown-item">Service 2</NavLink></li>
                        <li><NavLink to="/service3" className="dropdown-item">Service 3</NavLink></li>
                      </ul>
                    )}
                  </li>
                  <li className='nav-item'>
                    <NavLink to="/aboutus" className="nav-link" activeClassName="active">
                    ABOUT US 
                    </NavLink>
                  </li>
                  <li className='nav-item'>
                    <NavLink to="/contact" className="nav-link" activeClassName="active">
                      CONTACT US
                    </NavLink>
                  </li>
                  <li className='nav-item'>
                    <button className="btn btn-success mx-2">Request a Demo</button>
                  </li>
                  <li className='nav-item'>
                    <select className='form-control choose-lang'>
                      <option value='EN'>EN</option>
                      <option value='AR'>AR</option>
                    </select>
                  </li>
                </ul>
              </nav>
              <div className="menu-icon" onClick={toggleMenu}>
                &#9776;
              </div>
            </div>
          </div>
        </div>
      </header>
      {/* <section className='business-growth'>
        <Home />
      </section>
      <section className='logo-carousel'>
        <ListforCompanylogo />
        <section>
        <ProductIntro />
        </section>
        <section>
          <HomeaboutIntro />
        </section>
        <section>
          <Testimonials />
        </section>
        <section>
          <BusinessSolutions />
        </section>
        <section>
          <HomeFooter />
        </section>
      </section> */}
{/*       
      <ProductLandingpage /> */}
      <AboutUs />
      {/* <Services /> */}
      <Routes>
        <Route path='/' elements={<Home />} />
        <Route path='/product'  component={ProductLandingpage}/>
        <Route path='/services' elements={<AboutUs/>} />
        <Route path='/about' elements={<Services/>} />
        <Route path='/contact' elements={<></>} />
      </Routes>
    </div>
  );
}

export default App;

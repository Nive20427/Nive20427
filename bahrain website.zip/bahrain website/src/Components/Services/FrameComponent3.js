import PropTypes from "prop-types";
import "./FrameComponent3.css";

const FrameComponent3 = ({ className = "" }) => {
  return (
    <section className={`services-inner ${className}`}>
      <div className="services-intro-parent">
        <div className="services-intro">
          <div className="explore-our-services">
            Explore our services below to see how we can help your business
            thrive in the digital age.
          </div>
          <div className="services-description">
            <div className="our-range-of">{`Our range of IT services is designed to meet the diverse needs of businesses, ensuring efficiency, security, and innovation. `}</div>
          </div>
        </div>
        <div className="grid-container-wrapper">
          <div className="grid-container">
            <div className="frame-parent">
              <img
                className="instance-child"
                loading="lazy"
                alt=""
                src="/group-282.svg"
              />
              <div className="cloud-infrastructure">{`Cloud & Infrastructure`}</div>
              <div className="we-offer-comprehensive">
                We offer comprehensive cloud services and manage IT
                infrastructure to optimize performance and scalability, ensuring
                seamless operations.
              </div>
            </div>
            <div className="frame-group">
              <img
                className="instance-item"
                loading="lazy"
                alt=""
                src="/group-282.svg"
              />
              <div className="cloud-infrastructure1">
                Application Management Services
              </div>
              <div className="we-offer-comprehensive1">
                {" "}
                Our services oversee and optimize the performance, availability,
                and security of your enterprise applications, ensuring they
                align with your business goals.
              </div>
            </div>
            <div className="frame-container">
              <img
                className="instance-inner"
                loading="lazy"
                alt=""
                src="/group-282.svg"
              />
              <div className="cloud-infrastructure2">Product Development</div>
              <div className="we-offer-comprehensive2">
                From ideation to launch, we specialize in developing innovative
                products that meet market demands and drive business growth.
              </div>
            </div>
            <div className="frame-div">
              <img
                className="group-icon"
                loading="lazy"
                alt=""
                src="/group-282.svg"
              />
              <div className="cloud-infrastructure3">Customer Experience</div>
              <div className="we-offer-comprehensive3">
                We enhance customer engagement through web, mobile, and
                omnichannel experiences, ensuring seamless and satisfying
                experiences across all touchpoints.
              </div>
            </div>
            <div className="frame-parent1">
              <img
                className="instance-child1"
                loading="lazy"
                alt=""
                src="/group-282.svg"
              />
              <div className="cloud-infrastructure4">{`Data & Intelligence`}</div>
              <div className="we-offer-comprehensive4">
                Harness the power of data with our solutions that analyze and
                derive insights, empowering informed decisionmaking and
                strategic planning.
              </div>
            </div>
            <div className="frame-parent2">
              <img
                className="instance-child2"
                loading="lazy"
                alt=""
                src="/group-282.svg"
              />
              <div className="cloud-infrastructure5">Automations</div>
              <div className="we-offer-comprehensive5">
                We automate manual tasks using cutting-edge technologies, such
                as RPA and AI, to improve efficiency and reduce errors in your
                processes.
              </div>
            </div>
            <div className="frame-parent3">
              <img
                className="instance-child3"
                loading="lazy"
                alt=""
                src="/group-282.svg"
              />
              <div className="cloud-infrastructure6">Sustainability</div>
              <div className="we-offer-comprehensive6">
                We help businesses implement sustainable practices, including
                ESG reporting, carbon footprint analysis, and sustainable supply
                chain management, to reduce environmental impact and drive
                long-term value.
              </div>
            </div>
            <div className="frame-parent4">
              <img
                className="instance-child4"
                loading="lazy"
                alt=""
                src="/group-282.svg"
              />
              <div className="cloud-infrastructure7">{`Advisory, Consulting & Education  `}</div>
              <div className="we-offer-comprehensive7">
                Our experts provide strategic advice, consultancy, and
                educational programs to help you navigate the complex IT
                landscape and achieve your business objectives.
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

FrameComponent3.propTypes = {
  className: PropTypes.string,
};

export default FrameComponent3;
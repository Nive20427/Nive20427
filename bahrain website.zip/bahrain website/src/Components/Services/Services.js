import FrameComponent3 from './FrameComponent3';
import FrameComponent2 from './FrameComponent2';
import FrameComponent from './FrameComponent';
// import ServicesBgImg from '../../assests/ServicesBgImg';
import Footer from './Footer';
import "./Services.css";

const Services = () => {
  return (
    <div className="services">
      <section className="desktop-25-wrapper">
        {/* <img
          className="desktop-25"
          loading="lazy"
          alt=""
          src={ServicesBgImg}
        /> */}
      </section>
      <FrameComponent3 />
      <FrameComponent2 />
      <FrameComponent />
      <section className="separator">
        <div className="separator-child" />
      </section>
      <Footer />
    </div>
  );
};

export default Services;
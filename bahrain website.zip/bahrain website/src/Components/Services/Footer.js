import PropTypes from "prop-types";
import "./Footer.css";

const Footer = ({ className = "" }) => {
  return (
    <footer className={`footer ${className}`}>
      <div className="footer-container">
        <div className="footer1">
          <div className="company-name-parent">
            <div className="company-name">
              <h1 className="rapidqube">Rapidqube</h1>
            </div>
            <div className="partner-with-us">
              Partner with us to unlock your business's full potential.
            </div>
            <div className="social-media">
              <div className="social-media-icons">
                <div className="youtube-icon">
                  <img
                    className="logosyoutube-icon"
                    loading="lazy"
                    alt=""
                    src="/logosyoutubeicon.svg"
                  />
                </div>
                <div className="linkedin-icon">
                  <img
                    className="skill-iconslinkedin"
                    loading="lazy"
                    alt=""
                    src="/skilliconslinkedin.svg"
                  />
                </div>
                <img
                  className="logosfacebook-icon"
                  loading="lazy"
                  alt=""
                  src="/logosfacebook.svg"
                />
                <img
                  className="skill-iconsinstagram"
                  loading="lazy"
                  alt=""
                  src="/skilliconsinstagram.svg"
                />
                <div className="twitter-icon">
                  <img
                    className="pajamastwitter-icon"
                    loading="lazy"
                    alt=""
                    src="/pajamastwitter.svg"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="footer-container-inner">
          <div className="link-headers-parent">
            <div className="link-headers">
              <div className="our-links">Our Links</div>
            </div>
            <div className="product-links">
              <div className="product-link-items">
                <div className="products">Products</div>
              </div>
              <div className="service-links">
                <div className="services1">Services</div>
              </div>
              <div className="about-us-links">
                <div className="about-us">About us</div>
              </div>
              <div className="contact-links">
                <div className="contact">Contact</div>
              </div>
            </div>
          </div>
        </div>
        <div className="footer-container-child">
          <div className="frame-parent6">
            <div className="services-wrapper">
              <div className="services2">Services</div>
            </div>
            <div className="frame-parent7">
              <div className="cloud-infrastructure-wrapper">
                <div className="cloud-infrastructure8">{`Cloud & Infrastructure`}</div>
              </div>
              <div className="data-intelligence-wrapper">
                <div className="data-intelligence">{`Data & Intelligence`}</div>
              </div>
              <div className="product-development-wrapper">
                <div className="product-development">Product Development</div>
              </div>
              <div className="customer-experience-wrapper">
                <div className="customer-experience">Customer Experience</div>
              </div>
            </div>
          </div>
        </div>
        <div className="footer-container-inner1">
          <div className="frame-parent8">
            <div className="products-wrapper">
              <div className="products1">Products</div>
            </div>
            <div className="frame-parent9">
              <div className="r-suite-wrapper">
                <div className="r-suite">R-suite</div>
              </div>
              <div className="doct-wrapper">
                <div className="doct">docT</div>
              </div>
              <div className="rapidverse-wrapper">
                <div className="rapidverse">RapidVerse</div>
              </div>
              <div className="talkify-wrapper">
                <div className="talkify">Talkify</div>
              </div>
            </div>
          </div>
        </div>
        <div className="contact-form">
          <b className="lets-get-started">Lets Get Started</b>
          <div className="form-fields">
            <input className="name" placeholder="Name" type="text" />
          </div>
          <div className="form-fields1">
            <input className="work-mail" placeholder="Work Mail" type="text" />
          </div>
          <textarea
            className="form-fields2"
            placeholder="Message"
            rows={5}
            cols={18}
          />
          <button className="form-fields3">
            <div className="send">Send</div>
          </button>
        </div>
      </div>
      <div className="vector-parent">
        <img className="line-icon" loading="lazy" alt="" src="/line-510.svg" />
        <div className="copyright">
          <div className="copyright-2022-container">
            Copyright © 2022 RapidQube Digital Solutions WLL. All Rights
            Reserved. 
            <a
              className="privacy-policy"
              href="https://rapidqube.bh/privacyPolicy"
              target="_blank"
            >
              <span className="privacy-policy1">Privacy Policy</span>
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

Footer.propTypes = {
  className: PropTypes.string,
};

export default Footer;
import PropTypes from "prop-types";
import "./FrameComponent2.css";

const FrameComponent2 = ({ className = "" }) => {
  return (
    <section className={`desktop-23-wrapper ${className}`}>
      <div className="desktop-23">
        <div className="testimonial-content-wrapper">
          <div className="testimonial-content">
            <div className="rectangle-parent">
              <div className="frame-child" />
              <img
                className="teenyiconstick-outline"
                loading="lazy"
                alt=""
                src="/teenyiconstickoutline.svg"
              />
            </div>
            <div className="testimonial-icons">
              <div className="rectangle-group">
                <div className="frame-item" />
                <img
                  className="teenyiconstick-outline1"
                  loading="lazy"
                  alt=""
                  src="/teenyiconstickoutline-1.svg"
                />
              </div>
              <div className="rectangle-container">
                <div className="frame-inner" />
                <img
                  className="teenyiconstick-outline2"
                  loading="lazy"
                  alt=""
                  src="/teenyiconstickoutline-2.svg"
                />
              </div>
              <div className="group-div">
                <div className="rectangle-div" />
                <img
                  className="teenyiconstick-outline3"
                  loading="lazy"
                  alt=""
                  src="/teenyiconstickoutline-3.svg"
                />
              </div>
            </div>
          </div>
        </div>
        <div className="expert-team-our-team-of-certi-wrapper">
          <div className="expert-team-our-container">
            <p className="expert-team-our-team-of-certi">
              <span className="expert-team">Expert Team:</span>
              <span>
                {" "}
                Our team of certified professionals brings extensive experience
                and knowledge to every project.
              </span>
            </p>
            <p className="customized-solutions-we-tailo">
              <span className="customized-solutions">
                Customized Solutions:
              </span>
              <span>
                {" "}
                We tailor our services to meet your unique business needs and
                goals.
              </span>
            </p>
            <p className="proactive-support-we-stay-ahe">
              <span className="proactive-support">Proactive Support:</span>
              <span>
                {" "}
                We stay ahead of potential issues with proactive monitoring and
                maintenance.
              </span>
            </p>
            <p className="client-focused-our-client-fir">
              <span className="client-focused">Client-Focused</span>
              <span>
                : Our client-first approach ensures you receive the best
                possible service and support.
              </span>
            </p>
          </div>
        </div>
        <img
          className="desktop-23-child"
          loading="lazy"
          alt=""
          src="/frame-481@2x.png"
        />
      </div>
    </section>
  );
};

FrameComponent2.propTypes = {
  className: PropTypes.string,
};

export default FrameComponent2;
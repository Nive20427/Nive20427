import FrameComponent1 from "./FrameComponent1";
import PropTypes from "prop-types";
import "./FrameComponent.css";

const FrameComponent = ({ className = "" }) => {
  return (
    <section className={`services-child ${className}`}>
      <div className="review-content-parent">
        <div className="review-content">
          <div className="lorem-ipsum-dolor2">{`Lorem ipsum dolor sit amet, consectetur adipiscing  lorem dolor sed. m dolor `}</div>
          <div className="lorem-ipsum-dolor-sit-amet-co-wrapper">
            <div className="lorem-ipsum-dolor3">
              Lorem ipsum dolor sit amet, consectetur adipiscing lorem dolor
              sed. m dolor sit amet, consectetur adipiscing lorem dolor sed.
              ipsum dolor sit amet, consectetur adipiscing lorem d
            </div>
          </div>
        </div>
        <div className="image-carousel">
          <div className="carousel-images-parent">
            <div className="carousel-images">
              <div className="rectangle-parent1">
                <div className="frame-child1" />
                <div className="div">01</div>
              </div>
            </div>
            <div className="lorem-ipsum-dolor-sit-group">
              <h3 className="lorem-ipsum-dolor4">{`Lorem ipsum dolor sit  `}</h3>
              <div className="lorem-ipsum-dolor5">{`Lorem ipsum dolor sit amet, consectetur adipiscing  lorem dolor sed. m dolor sit amet, m dolor sit amet, `}</div>
            </div>
          </div>
          <div className="image-container">
            <FrameComponent1 imagePlaceholder="02" />
            <FrameComponent1
              imagePlaceholder="03"
              propBackgroundImage="url('/frame-584@3x.png')"
              propOverflow="hidden"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

FrameComponent.propTypes = {
  className: PropTypes.string,
};

export default FrameComponent;
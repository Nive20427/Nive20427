import { useMemo } from "react";
import PropTypes from "prop-types";
import './FrameComponent1.css'

const FrameComponent1 = ({
  className = "",
  imagePlaceholder,
  propBackgroundImage,
  propOverflow,
}) => {
  const frameDivStyle = useMemo(() => {
    return {
      backgroundImage: propBackgroundImage,
      overflow: propOverflow,
    };
  }, [propBackgroundImage, propOverflow]);

  return (
    <div className={`frame-parent5 ${className}`}>
      <div className="image-content-wrapper" style={frameDivStyle}>
        <div className="image-content">
          <div className="image-content-child" />
          <div className="image-placeholder">{imagePlaceholder}</div>
        </div>
      </div>
      <div className="lorem-ipsum-dolor-sit-parent">
        <h3 className="lorem-ipsum-dolor">{`Lorem ipsum dolor sit  `}</h3>
        <div className="lorem-ipsum-dolor1">{`Lorem ipsum dolor sit amet, consectetur adipiscing  lorem dolor sed. m dolor sit amet, m dolor sit amet, `}</div>
      </div>
    </div>
  );
};

FrameComponent1.propTypes = {
  className: PropTypes.string,
  imagePlaceholder: PropTypes.string,

  /** Style props */
  propBackgroundImage: PropTypes.any,
  propOverflow: PropTypes.any,
};

export default FrameComponent1;
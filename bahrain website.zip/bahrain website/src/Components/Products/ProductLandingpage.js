import React from 'react';
import './ProductLandingpage.css';
import Challenges from './Challenges';
import WhyChooseUs from './WhyChooseUs';
import AskforDemo from './AskforDemo';
import ProductCarousel from './ProductCarousel';
import ProductFooter from './ProductFooter';
function ProductLandingPage() {
  return (
    <div>
      <section className="container-fluid landing-page">
        <div className="row feature-section">
          <div className="col-12 product-component">
            <h1 className="product-title">FEATURES THAT MAKE <br />SELLING EASIER</h1>
            <p className="product-content">
              Experience the future of customer interaction with Talkify, the ultimate Conversational AI solution designed to
              transform the way you engage with your customers. Talkify revolutionizes customer service, automates routine
              tasks, and boosts efficiency, offering a seamless blend of advanced AI and user-friendly design.
            </p>
            <div className="text-center">
              <button className="btn btn-primary custom-button">Request a Demo</button>
            </div>
          </div>
        </div>
      </section>
      <section className="container challenges-section">
        <Challenges />
      </section>
      <section className="container whyChooseUs-section">
        <WhyChooseUs />
      </section>
      <section className="container askforDemo-section">
        <AskforDemo />
      </section>
      <section className="container productCarousel-section">
        <ProductCarousel />
      </section>
      <section className="container productFooter-section">
        <ProductFooter />
      </section>
      </div>
  );
}

export default ProductLandingPage;

import React from 'react';
import './Challenges.css';

function Challenges() {
  const challengesData = [
    { title: '01', subtitle: 'Gen AI', text: 'Gen AI is a cutting-edge platform that harnesses the power of artificial intelligence to produce a wide range of creative text.', bgColor: 'white', color: 'black' },
    { title: '02', subtitle: 'Natural Language Processing', text: 'Natural Language Processing (NLP) is a technology that helps machines understand and interpret human languages.', bgColor: 'black', color: 'white', borderColor: 'white' },
    { title: '03', subtitle: 'Ticketing System', text: 'A ticketing system automates the process of creating support tickets, streamlining customer support and improving efficiency.', bgColor: 'white', color: 'black' },
    { title: '04', subtitle: 'ERP Integration', text: 'ERP integration allows for a smooth and efficient connection between your current Enterprise Resource Planning system and other software or technologies.', bgColor: 'white', color: 'black' },
    { title: '05', subtitle: '24/7 Availability', text: 'This allows for a high level of convenience and responsiveness for customers, leading to improved satisfaction and retention.', bgColor: 'black', color: 'white', borderColor: 'white' },
    { title: '06', subtitle: 'Multilingual Support', text: 'Multilingual support allows businesses to communicate with customers in various languages.', bgColor: 'white', color: 'black' },
    { title: '07', subtitle: 'ERP Integration', text: 'ERP integration allows for a smooth and efficient connection between your current Enterprise Resource Planning system and other software or technologies.', bgColor: 'white', color: 'black' },
    { title: '08', subtitle: '24/7 Availability', text: 'This allows for a high level of convenience and responsiveness for customers, leading to improved satisfaction and retention.', bgColor: 'black', color: 'white', borderColor: 'white' },
    { title: '09', subtitle: 'Multilingual Support', text: 'Multilingual support allows businesses to communicate with customers in various languages.', bgColor: 'white', color: 'black' },
  ];

  return (
    <div className="container text-center">
      <h2 className="challenges-header">RapidQube Digital is a disruptive, results-driven,<br/> next-gen IT services provider solving the <br/> modern digital challenges and</h2>
      <div className="row justify-content-center challenges-container">
        {challengesData.map((challenge, index) => (
          <div key={index} className="col-md-4 mb-4">
            <div className="card feature-card" style={{ backgroundColor: challenge.bgColor, color: challenge.color, borderColor: challenge.borderColor || 'transparent' }}>
              <div className="card-body">
                <div className="semi-circle"></div>
                <h5 className="card-title">{challenge.title}</h5>
                <h6 className="card-subtitle mb-2">{challenge.subtitle}</h6>
                <p className="card-text">{challenge.text}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Challenges;

import React from 'react';
import './AskforDemo.css';
function AskforDemo() {
    return (

        <div className="askforDemo-container">
            <div className="overlay">
                <button className="demo-button">Ask for Demo</button>
            </div>
        </div>

    )
}

export default AskforDemo
// import React,{useState} from 'react';
// import { Carousel, Card, Button, Container, Row, Col } from 'react-bootstrap';
// import './ProductCarousel.css';

// function ProductCarousel() {
//   const products = [
//     {
//       title: 'R-Suite',
//       description: 'Transform your business processes with R-Suite, the ultimate ERP solution tailored to meet the unique needs of your organization.',
//       image: 'path-to-your-image.jpg',
//       buttonText: 'View Product',
//     },
//     {
//       title: 'R-Suite',
//       description: 'Transform your business processes with R-Suite, the ultimate ERP solution tailored to meet the unique needs of your organization.',
//       image: 'path-to-your-image.jpg',
//       buttonText: 'View Product',
//     },
//     {
//       title: 'R-Suite',
//       description: 'Transform your business processes with R-Suite, the ultimate ERP solution tailored to meet the unique needs of your organization.',
//       image: 'path-to-your-image.jpg',
//       buttonText: 'View Product',
//     },
//     {
//       title: 'R-Suite',
//       description: 'Transform your business processes with R-Suite, the ultimate ERP solution tailored to meet the unique needs of your organization.',
//       image: 'path-to-your-image.jpg',
//       buttonText: 'View Product',
//     },
//     {
//       title: 'R-Suite',
//       description: 'Transform your business processes with R-Suite, the ultimate ERP solution tailored to meet the unique needs of your organization.',
//       image: 'path-to-your-image.jpg',
//       buttonText: 'View Product',
//     },
//     {
//       title: 'R-Suite',
//       description: 'Transform your business processes with R-Suite, the ultimate ERP solution tailored to meet the unique needs of your organization.',
//       image: 'path-to-your-image.jpg',
//       buttonText: 'View Product',
//     },
//   ];
//   const [index, setIndex] = useState(0);

//   const handleSelect = (selectedIndex, e) => {
//     setIndex(selectedIndex);
//   };
//   return (
//     <Container className="my-5">
//     <Carousel activeIndex={index} onSelect={handleSelect} indicators={false} controls={false}>
//       {[0, 1].map((slideIndex) => (
//         <Carousel.Item key={slideIndex}>
//           <Row className="justify-content-center">
//             {products.slice(slideIndex * 3, slideIndex * 3 + 3).map((product, idx) => (
//               <Col key={idx} md={4} className="d-flex justify-content-center">
//                 <Card className="product-card mb-4">
//                   <Card.Img variant="top" src={product.image} />
//                   <Card.Body>
//                     <Card.Title>{product.title}</Card.Title>
//                     <Card.Text>{product.description}</Card.Text>
//                     <Button variant="success">{product.buttonText}</Button>
//                   </Card.Body>
//                 </Card>
//               </Col>
//             ))}
//           </Row>
//         </Carousel.Item>
//       ))}
//     </Carousel>
//     <div className="carousel-controls">
//       {index > 0 && (
//         <Button variant="secondary" onClick={() => setIndex(index - 1)}>
//           Previous
//         </Button>
//       )}
//       {index < products.length / 3 - 1 && (
//         <Button variant="secondary" onClick={() => setIndex(index + 1)}>
//           Next
//         </Button>
//       )}
//     </div>
//   </Container>
//   );
// }

// export default ProductCarousel;

import React, { useState } from 'react';
import { Carousel, Card, Button, Container } from 'react-bootstrap';
import productCarousel from '../../assests/productCarousel.jpg';
import './ProductCarousel.css';

function ProductCarousel() {
  const products = [
    {
      title: 'R-Suite',
      description: 'Transform your business processes with R-Suite, the ultimate ERP solution tailored to meet the unique needs of your organization.',
      image:{productCarousel},
      buttonText: 'View Product',
    },
    {
      title: 'R-Suite',
      description: 'Transform your business processes with R-Suite, the ultimate ERP solution tailored to meet the unique needs of your organization.',
      image: {productCarousel},
      buttonText: 'View Product',
    },
    {
      title: 'R-Suite',
      description: 'Transform your business processes with R-Suite, the ultimate ERP solution tailored to meet the unique needs of your organization.',
      image: {productCarousel},
      buttonText: 'View Product',
    },
    {
      title: 'R-Suite',
      description: 'Transform your business processes with R-Suite, the ultimate ERP solution tailored to meet the unique needs of your organization.',
      image: {productCarousel},
      buttonText: 'View Product',
    },
    {
      title: 'R-Suite',
      description: 'Transform your business processes with R-Suite, the ultimate ERP solution tailored to meet the unique needs of your organization.',
      image: {productCarousel},
      buttonText: 'View Product',
    },
    {
      title: 'R-Suite',
      description: 'Transform your business processes with R-Suite, the ultimate ERP solution tailored to meet the unique needs of your organization.',
      image: {productCarousel},
      buttonText: 'View Product',
    },
  ];

  const [index, setIndex] = useState(0);

  const handleSelect = (selectedIndex, e) => {
    setIndex(selectedIndex);
  };

  return (
    <Container className="my-5">
      <Carousel activeIndex={index} onSelect={handleSelect} indicators={false} controls={false}>
        {products.map((product, idx) => (
          <Carousel.Item key={idx}>
            <div className="d-flex justify-content-center">
              <Card className="product-card mb-4">
                <Card.Img variant="top" src={product.image} />
                <Card.Body>
                  <Card.Title>{product.title}</Card.Title>
                  <Card.Text>{product.description}</Card.Text>
                  <Button variant="success">{product.buttonText}</Button>
                </Card.Body>
              </Card>
            </div>
          </Carousel.Item>
        ))}
      </Carousel>
      <div className="carousel-controls">
        {index > 0 && (
          <Button variant="secondary" onClick={() => setIndex(index - 1)}>
            Previous
          </Button>
        )}
        {index < products.length - 1 && (
          <Button variant="secondary" onClick={() => setIndex(index + 1)}>
            Next
          </Button>
        )}
      </div>
    </Container>
  );
}

export default ProductCarousel;



// position: absolute;
// width: 448px;
// height: 625px;
// left: 699.97px;
// top: 3411.25px;

// background: #02720D;
// border-radius: 20px;

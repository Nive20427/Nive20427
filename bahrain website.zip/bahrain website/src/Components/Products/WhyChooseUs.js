import React from 'react';
import './WhyChooseUS.css';

function WhyChooseUs() {
  const cardsData = [
    { title: 'Increase Efficiency', text: 'Increasing efficiency with advanced technology, RapidQube streamlines processes for optimal performance and productivity.', icon: 'icon-path',bgColor: 'black'  },
    { title: 'Improved Customer Satisfaction', text: 'Enhancing customer experience through innovative tech solutions, RapidQube ensures seamless, efficient, and user-friendly digital interactions for all.', icon: 'icon-path',bgColor: 'rgba(2, 114, 13, 1)' },
    { title: 'Increased Efficiency', text: 'Enhancing customer experience through innovative tech solutions, RapidQube ensures seamless, efficient, and user-friendly digital interactions for all.', icon: 'icon-path' ,bgColor: 'black'},
    { title: 'Enhanced User Experience', text: 'Enhancing user experience through innovative technology, RapidQube delivers intuitive and seamless digital interactions for all users.', icon: 'icon-path',bgColor: 'rgba(2, 114, 13, 1)' },
    { title: 'Reduced Costs', text: 'Reducing costs with innovative technology, RapidQube optimizes resources to maximize savings and efficiency.', icon: 'icon-path' ,bgColor: 'black'},
    { title: 'Faster Response Times', text: 'Accelerating response times with cutting-edge technology, RapidQube ensures quick and efficient service delivery for all clients.', icon: 'icon-path' ,bgColor: 'rgba(2, 114, 13, 1)'},
  ];

  return (
    <div className="container text-center">
      <h2 className="why-choose-header">Why Choose Us</h2>
      <p className="why-choose-text">RapidQube Digital is a disruptive, results-driven, <br/>next-gen IT services provider solving the modern <br/>digital challenges and</p>
      <div className="row justify-content-center">
        {cardsData.map((card, index) => (
          <div key={index} className="col-md-4 mb-4">
            <div className="card why-choose-card" style={{ backgroundColor: card.bgColor }}>
              <div className="card-body">
                <div className="card-icon">
                  <img src={card.icon}  />
                </div>
                <h5 className="card-title">{card.title}</h5>
                <p className="card-text">{card.text}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default WhyChooseUs;
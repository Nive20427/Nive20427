import React from 'react';
import Instagram from '../assests/Instagram.png';
import LinkedIn from '../assests/LinkedIn.png';
import Facebook from '../assests/Facebook.png';
import TwitterX from '../assests/TwitterX.png';
import './HomeFooter.css';


const Footer = () => {
  return (
    <footer className="footer">
    <div className="container">
      <div className="row">
        <div className="col-lg-4 col-md-12 order-md-1">
          <div className="footer-left">
            <h2 className="logo">Rapidqube</h2>
            <p className="slogan">Partner with us to unlock your<br/> business's full potential.</p>
            <div className="social-icons">
              <a href="#" className="social-icon">
                 <img src={LinkedIn} alt='Instagram'/></a>
              <a href="#" className="social-icon">
                < img src={Facebook} alt='Instagram' /></a>
              <a href="#" className="social-icon">
                <img src={Instagram} alt='Instagram'  /></a>
              <a href="#" className="social-icon">
                <img src={TwitterX} alt='Instagram'  /></a>
            </div>
          </div>
        </div>
        <div className="col-lg-4 col-md-12 order-md-2">
          <div className="footer-middle">
            <div className="footer-links">
              <div className="row">
                <div className="col-md-4">
                  <ul className="list-unstyled">
                    <h6 style={{color:'rgba(2, 114, 13, 1)'}}>Our Links</h6>
                    <li>Products</li>
                    <li>Services</li>
                    <li>About us</li>
                    <li>Contact</li>
                  </ul>
                </div>
                <div className="col-md-4">
                  <ul className="list-unstyled">
                    <h6 style={{color:'rgba(2, 114, 13, 1)'}}>Services</h6>
                    <li>Cloud & Infrastructure</li>
                    <li>Data & Intelligence</li>
                    <li>Product development </li>
                    <li>Customer Experience</li>
                  </ul>
                </div>
                <div className="col-md-4">
                  <ul className="list-unstyled" style={{marginLeft:'20%'}}>
                    <h6 style={{color:'rgba(2, 114, 13, 1)'}}>Products</h6>
                    <li>R-suite</li>
                    <li>docT</li>
                    <li>RapidVerse</li>
                    <li>Talkify</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="col-lg-4 col-md-12 order-md-3">
          <div className="footer-right">
            
            <form>
            <h3 className="section-title text-center" style={{color:'white'}}>Let's Get Started</h3>
              <input type="text" placeholder="Name" className="form-input" />
              <input type="email" placeholder="Work Mail" className="form-input" />
              <textarea placeholder="Message" className="form-textarea"></textarea>
              <button type="submit" className="btn btn-primary">Send</button>
            </form>
          </div>
        </div>
      </div>
    </div>
    <hr style={{marginTop:'50px'}} />
    <div className="footer-bottom">
      <div className="container">
        <p>&copy; 2024 RapidQube Digital Solutions WLL. All Rights Reserved. <a href="#" className="privacy-link">Privacy Policy</a></p>
      </div>
    </div>
  </footer>
  );
};

export default Footer;
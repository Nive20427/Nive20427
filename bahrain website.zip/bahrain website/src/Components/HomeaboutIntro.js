import React from 'react';
import homeaboutIntroImg from '../assests/homeaboutIntroImg.jpg';

function HomeaboutIntro() {
  return (
    <div className="about-us-section container-fluid">
      <div className="row align-items-center justify-content-center" style={{backgroundColor:'black', color:'white'}}>
        <div className="col-md-6 p-0 img-container d-flex justify-content-center align-items-center">
          <img src={homeaboutIntroImg} alt="About Us" className="img-fluid about-us-image" />
        </div>
        <div className="col-md-6 about-us-content">
          <h2 className="about-us-heading">About Us</h2>
          <p className='about-us-paragraph' style={{whiteSpace:'break-spaces'}}>
            RapidQube Digital is a disruptive, results-driven, next-gen IT services provider solving the modern digital
            challenges and assisting customers to adopt digital technologies with best-in-class services. We help
            accelerate digital transformation through the development and deployment of cutting-edge solutions applying
            the blockchain ecosystem along with IoT, Machine Learning (ML), Integration, and in the omnichannel space.
          </p>
          <button className="btn btn-success">Know More</button>
        </div>
      </div>
    </div>
  );
}

export default HomeaboutIntro;
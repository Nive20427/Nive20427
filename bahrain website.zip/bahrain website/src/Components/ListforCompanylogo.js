import React from 'react'
import Techzert from '../assests/Techzert.png';
import Eterna from '../assests/Eterna.png';
import  NLSG from '../assests/NLSG.png';
import MahaIT from '../assests/MahaIT.png';
import RQ from '../assests/RQ.png';

function ListforCompanylogo() {
    return (
        <div className="carousel-container">
            <div className="carousel-track">
                <div className="carousel-item">
                    <img src={Techzert} alt="Techizert" className="img-fluid" />
                </div>
                <div className="carousel-item">
                    <img src={Eterna} alt="EternaServices" className="img-fluid" />
                </div>
                <div className="carousel-item">
                    <img src={NLSG} alt="NLSA" className="img-fluid" />
                </div>
                <div className="carousel-item">
                    <img src={MahaIT} alt="Mathnit" className="img-fluid" />
                </div>
                <div className="carousel-item">
                    <img src={RQ} alt="RapidQube" className="img-fluid" />
                </div>
              
            </div>
        </div>
    )
}

export default ListforCompanylogo;
import BenefitCard1 from './BenefitCard1';
import BenefitCard from './BenefitCard';
import PropTypes from "prop-types";
import "./FrameComponent.css";

const FrameComponent = ({ className = "" }) => {
  return (
    <section className={`about-us-child ${className}`}>
      <div className="frame-group">
        <div className="benefit-card-parent">
          <div className="benefit-card2">
            <div className="card-number2">
              <div className="card-number-inner" />
              <div className="div1">2016</div>
            </div>
            <b className="concept-research">Concept Research</b>
            <p className="formed-in-mumbaiindia-container">
              <ul className="formed-in-mumbaiindia-started">
                <li className="formed-in-mumbaiindia">
                  Formed In Mumbai,India
                </li>
                <li>Started Operations with 3 Employees</li>
              </ul>
            </p>
          </div>
          <BenefitCard1
            prop="2017"
            commitment="Commitment"
            wonTheFirstBlockchainProj="Won the First Blockchain Project for Healthcare"
            wonHackathons="Won Hackathons"
            activeParticipantInVariou={`Active Participant in Various Webinars & Events as Speaker Contestant `}
            stCorporateBlockchainTrai="1st Corporate Blockchain Training"
            stProjectForPublicSector="1st Project for Public Sector"
          />
        </div>
        <div className="engagement-card">
          <div className="engagement-content">
            <div className="benefit-card-wrapper">
              <BenefitCard
                engagementSeparator="2018"
                engagement="Engagement"
                establishedDevelopmentCen="Established Development Center at Chennai"
                stBlockchainProjectForIns="1st Blockchain Project for Insurance Sector"
                stOverseasBlockchainProje="1st Overseas Blockchain Project in UAE"
                stPOCForMaharashtraGovern="1st POC for Maharashtra Government"
                pOCForLegalHealthCarePubl="6POC for Legal, Health Care,  Public Sector "
              />
            </div>
            <blockquote className="utilizing-transformative-techn1">
              "Utilizing <br/>transformative <br/>technologies for <br/>sustainable<br/> solutions"
            </blockquote>
          </div>
          <div className="scaling-card">
            <BenefitCard
              engagementSeparator="2019"
              engagement="Adoption"
              establishedDevelopmentCen="Got ISO 2015 Certified"
              stBlockchainProjectForIns={`Launched AI and Blockchain Consultancy Services & Won 1st AI Project`}
              stOverseasBlockchainProje="Extended Our Footstep in USA Market"
              stPOCForMaharashtraGovern="1st Blockchain Project for MH Government"
              pOCForLegalHealthCarePubl="Featured in Insight Success Magazine"
              propFlex="unset"
              propAlignSelf="stretch"
              propTop="-0.062rem"
              propLeft="0.5rem"
              propHeight="unset"
              propDisplay="unset"
            />
            <BenefitCard1
              prop="2020"
              commitment="Scaling"
              wonTheFirstBlockchainProj="Regsitered Company in USA"
              wonHackathons="1st Project for one of the Biggest Manufacturing Company at Bahrain"
              activeParticipantInVariou="Renewal of ISO 2015 Certificate"
              stCorporateBlockchainTrai="Multiple Projects for Digital Transformations"
              stProjectForPublicSector={`Expanding Reach to 4 Countries & 5 States`}
              propPadding="1.125rem 1.187rem 1.437rem"
              propLeft="-0.062rem"
              propHeight="14.625rem"
              propDisplay="inline-block"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

FrameComponent.propTypes = {
  className: PropTypes.string,
};

export default FrameComponent;
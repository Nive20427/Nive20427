import PropTypes from "prop-types";
import Instagram from '../../assests/Instagram.png';
import LinkedIn from '../../assests/LinkedIn.png';
import Facebook from '../../assests/Facebook.png';
import TwitterX from '../../assests/TwitterX.png';
import "./Footer.css";

const Footer = ({ className = "" }) => {
  return (
    <footer className={`footer ${className}`}>
      <div className="footer-contact-parent">
        <div className="footer-contact">
          <div className="footer-contact-content">
            <div className="footer-brand">
              <h1 className="rapidqube2">Rapidqube</h1>
            </div>
            <div className="partner-with-us">
              Partner with us to unlock your <br/>  business's full potential.
            </div>
            <div className="footer-socials">
              <div className="footer-social-icons">
              
            
                <div className="footer-social-icon-linkedin">
                  <img
                    className="skill-iconslinkedin3"
                    alt=""
                    src={LinkedIn}
                  />
                </div>
                <img
                  className="logosfacebook-icon"
                  loading="lazy"
                  alt=""
                  src={Facebook}
                />
                <img
                  className="skill-iconsinstagram"
                  loading="lazy"
                  alt=""
                  src={Instagram}
                />
                <div className="footer-social-icon-twitter">
                  <img
                    className="pajamastwitter-icon"
                    loading="lazy"
                    alt=""
                    src={TwitterX}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="frame-wrapper">
          <div className="frame-container">
            <div className="our-links-wrapper">
              <b className="our-links">Our Links</b>
            </div>
            <div className="frame-div">
              <div className="products-wrapper">
                <div className="products3">Products</div>
              </div>
              <div className="footer-sublinks-services">
                <div className="services1">Services</div>
              </div>
              <div className="footer-sublinks-contact">
                <div className="about-us2">About us</div>
              </div>
              <div className="footer-sublinks-contact1">
                <div className="contact">Contact</div>
              </div>
            </div>
          </div>
        </div>
        <div className="frame-wrapper1">
          <div className="frame-parent1">
            <div className="services-wrapper">
              <b className="services2">Services</b>
            </div>
            <div className="frame-parent2">
              <div className="cloud-infrastructure-wrapper">
                <div className="cloud-infrastructure">{`Cloud & Infrastructure`}</div>
              </div>
              <div className="data-intelligence-wrapper">
                <div className="data-intelligence">{`Data & Intelligence`}</div>
              </div>
              <div className="product-development-wrapper">
                <div className="product-development">Product Development</div>
              </div>
              <div className="customer-experience-wrapper">
                <div className="customer-experience">Customer Experience</div>
              </div>
            </div>
          </div>
        </div>
        <div className="frame-wrapper2">
          <div className="frame-parent3">
            <div className="products-container">
              <b className="products4">Products</b>
            </div>
            <div className="frame-parent4">
              <div className="r-suite-wrapper">
                <div className="r-suite">R-suite</div>
              </div>
              <div className="doct-wrapper">
                <div className="doct">docT</div>
              </div>
              <div className="rapidverse-wrapper">
                <div className="rapidverse">RapidVerse</div>
              </div>
              <div className="talkify-wrapper">
                <div className="talkify">Talkify</div>
              </div>
            </div>
          </div>
        </div>
        <div className="footer-form">
          <b className="lets-get-started">Lets Get Started</b>
          <div className="footer-form-fields">
            <input className="name" placeholder="Name" type="text" />
          </div>
          <div className="footer-form-fields1">
            <input className="work-mail" placeholder="Work Mail" type="text" />
          </div>
          <textarea
            className="footer-form-fields2"
            placeholder="Message"
            rows={5}
            cols={18}
          />
          <button className="footer-form-fields3">
            <b className="send">Send</b>
          </button>
        </div>
      </div>
      <div className="copyright">
        <img
          className="copyright-child"
          loading="lazy"
          alt=""
          src="/line-510.svg"
        />
        <div className="copyright-content">
          <div className="copyright-2022-container">
            Copyright © 2022 RapidQube Digital Solutions WLL. All Rights
            Reserved. 
            <a
              className="privacy-policy"
              href="https://rapidqube.bh/privacyPolicy"
              target="_blank"
            >
              <span className="privacy-policy1">Privacy Policy</span>
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

Footer.propTypes = {
  className: PropTypes.string,
};

export default Footer;
import { useMemo } from "react";
import PropTypes from "prop-types";
import "./BenefitCard1.css";

const BenefitCard1 = ({
  className = "",
  prop,
  commitment,
  wonTheFirstBlockchainProj,
  wonHackathons,
  activeParticipantInVariou,
  stCorporateBlockchainTrai,
  stProjectForPublicSector,
  propPadding,
  propLeft,
  propHeight,
  propDisplay,
}) => {
  const benefitCardStyle = useMemo(() => {
    return {
      padding: propPadding,
    };
  }, [propPadding]);

  const divStyle = useMemo(() => {
    return {
      left: propLeft,
    };
  }, [propLeft]);

  const wonTheFirstContainerStyle = useMemo(() => {
    return {
      height: propHeight,
      display: propDisplay,
    };
  }, [propHeight, propDisplay]);

  return (
    <div className={`benefit-card ${className}`} style={benefitCardStyle}>
      <div className="card-number">
        <div className="card-number-child" />
        <div className="div" style={divStyle}>
          {prop}
        </div>
      </div>
      <b className="commitment">{commitment}</b>
      <p className="won-the-first-container" style={wonTheFirstContainerStyle}>
        <ul className="won-the-first-blockchain-proje">
          <li className="won-the-first">{wonTheFirstBlockchainProj}</li>
          <li className="won-hackathons">{wonHackathons}</li>
          <li className="active-participant-in">{activeParticipantInVariou}</li>
          <li className="st-corporate-blockchain">
            {stCorporateBlockchainTrai}
          </li>
          <li>{stProjectForPublicSector}</li>
        </ul>
      </p>
    </div>
  );
};

BenefitCard1.propTypes = {
  className: PropTypes.string,
  prop: PropTypes.string,
  commitment: PropTypes.string,
  wonTheFirstBlockchainProj: PropTypes.string,
  wonHackathons: PropTypes.string,
  activeParticipantInVariou: PropTypes.string,
  stCorporateBlockchainTrai: PropTypes.string,
  stProjectForPublicSector: PropTypes.string,

  /** Style props */
  propPadding: PropTypes.any,
  propLeft: PropTypes.any,
  propHeight: PropTypes.any,
  propDisplay: PropTypes.any,
};

export default BenefitCard1;
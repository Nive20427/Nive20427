import PropTypes from "prop-types";
import LinkedIn from '../../assests/LinkedIn.png'
import CEO from '../../assests/CEOImg.png';
import MuthuPrakashVP from '../../assests/MuthuPrakashVP.png';
import MohanVP from '../../assests/MohanVP.png';
import "./Leadership.css";

const Leadership = ({ className = "" }) => {
  return (
    <section className={`leadership ${className}`}>
      <div className="leadership-content">
        <div className="leadership-profiles">
          <div className="profile">
            <div className="profile-content">
              <img
                className="image-16442-icon"
                alt=""
                src={CEO}
              />
             
            </div>
          </div>
          <div className="co-founder-details">
            <div className="co-founder-details-child" />
            <b className="raghunath-vaddadi">Raghunath Vaddadi</b>
            <div className="co-founder-position">
              <div className="co-founder-ceo1">{`Co-Founder & CEO`}</div>
            </div>
            <div className="skill-iconslinkedin-wrapper">
              <img
                className="skill-iconslinkedin"
                loading="lazy"
                alt=""
                src={LinkedIn}
              />
            </div>
          </div>
        </div>
        <div className="v-p-profile">
          <div className="v-p-content">
            <img
              className="image-16440-icon"
              loading="lazy"
              alt=""
              src={MuthuPrakashVP}
            />
            <div className="profile-image">
              <div className="profile-image-child" />
              <div className="profile-details-container">
                <b className="muthuprakash-ravindran">Muthuprakash Ravindran</b>
                <div className="profile-designation">
                  <div className="vice-president">Vice President</div>
                </div>
              </div>
              <div className="profile-link">
                <img
                  className="skill-iconslinkedin1"
                  alt=""
                  src={LinkedIn}
                />
              </div>
            </div>
          </div>
          <div className="profile-image1">
            <img
              className="image-16441-icon1"
              alt=""
              src={MohanVP}
            />
            <div className="profile-details-container1">
              <div className="profile-details-container-child" />
              <b className="mohanraj-polurbalu">Mohanraj Polurbalu</b>
              <div className="profile-designation1">
                <div className="vice-president1">Vice President</div>
              </div>
              <div className="profile-link1">
                <img
                  className="skill-iconslinkedin2"
                  alt=""
                  src={LinkedIn}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

Leadership.propTypes = {
  className: PropTypes.string,
};

export default Leadership;
// import PropTypes from "prop-types";
// import "./FrameComponent1.css";
// import productCarousel from '../../assests/productCarousel.jpg';

// const FrameComponent1 = ({ className = "" }) => {
//   return (
//     <div className={`inner-content-wrapper ${className}`}>
//       <header className="inner-content">
//         <img
//           className="inner-content-child"
//           alt=""
//           src={productCarousel}
//         />
//         <div className="frame-parent">
//           <div className="rapidqube-parent">
//             <a className="rapidqube1">Rapidqube</a>
//             <div className="transforming-business-paradigm">
//               Transforming Business Paradigms
//             </div>
//           </div>
//           <div className="navigation-links-wrapper">
//             <div className="navigation-links">
//               <div className="link-items">
//                 <a className="home">HOME</a>
//               </div>
//               <div className="product-link">
//                 <div className="product-dropdown">
//                   <a className="products">{`PRODUCTS `}</a>
//                   <div className="product-dropdown-icon">
//                     <img className="vector-icon" alt="" src="/vector.svg" />
//                   </div>
//                 </div>
//               </div>
//               <div className="instance-link">
//                 <div className="products1">
//                   <a className="products2">ABOUT US</a>
//                 </div>
//               </div>
//               <div className="link-items1">
//                 <a className="services">SERVICES</a>
//               </div>
//               <div className="link-items2">
//                 <a className="contact-us">CONTACT US</a>
//               </div>
//               <button className="demo-link">
//                 <a className="request-a-demo">Request a Demo</a>
//               </button>
//             </div>
//           </div>
//           <div className="icon" />
//         </div>
//       </header>
//     </div>
//   );
// };

// FrameComponent1.propTypes = {
//   className: PropTypes.string,
// };

// export default FrameComponent1;

// import PropTypes from "prop-types";
// import "./FrameComponent1.css";
// import productCarousel from '../../assests/productCarousel.jpg';

// const FrameComponent1 = ({ className = "" }) => {
//   return (
    
//         <img alt="" src={productCarousel} />

     
 
//   );
// };

// FrameComponent1.propTypes = {
//   className: PropTypes.string,
// };

// export default FrameComponent1;
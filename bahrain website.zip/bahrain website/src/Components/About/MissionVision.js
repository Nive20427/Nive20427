import PropTypes from "prop-types";
import "./MissionVision.css";
import missionvision from '../../assests/missionvision.png';
import missionvisionImg2 from '../../assests/missionvisionImg2.png';
const MissionVision = ({ className = "" }) => {
  return (
    <section className={`mission-vision ${className}`}>
      <img
        className="mission-vision-rect"
        loading="lazy"
        alt=""
        src={missionvision}
      />
      <div className="mission-vision-content">
        <div className="mission-content">
          <div className="our-mission-wrapper">
            <h1 className="our-mission">
              <span>{`Our `}</span>
              <span className="mission">{`Mission  `}</span>
            </h1>
          </div>
          <div className="vision-content">
            <div className="vision-description-parent">
              <div className="vision-description">
                <p className="our-mission-is">
                  Our Mission is to help our clients achieve and exceed <br/>their
                  digital technology adaptation goals and make <br/>digital
                  technology become a pillar of their business<br/> growth and
                  profitability.
                </p>
              </div>
              <div className="vision-title">
                <h1 className="our-vision">
                  <span>{`Our `}</span>
                  <span className="vision">{`Vision `}</span>
                </h1>
                <div className="vision-elaboration">
                  <p className="our-vision-is">
                    Our Vision is to become the incubator for digital<br/>
                    technology, innovating, disrupting, and delivering<br/>
                    successful future-ready business solutions through<br/> the
                    development and deployment of futuristic<br/> technologies.
                  </p>
                </div>
              </div>
            </div>
            <div className="vision-rect">
              <img
                className="mission-vision-image"
                loading="lazy"
                alt=""
                src={missionvisionImg2}
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

MissionVision.propTypes = {
  className: PropTypes.string,
};

export default MissionVision;
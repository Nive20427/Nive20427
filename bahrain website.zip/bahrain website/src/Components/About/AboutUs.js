// import FrameComponent1 from '../About/FrameComponent1';
import MissionVision from '../About/MissionVision';
import FrameComponent from '../About/FrameComponent';
import Leadership from '../About/Leadership';
import Footer from '../About/Footer';
import "./AboutUs.css";
import productCarousel from '../../assests/productCarousel.jpg';

function AboutUs () {
  return (
      <div className="about-us">
    <div className="about-us-inner">
      <div className="content-parent">
        <div className="content" />
        <img className="image-16441-icon" alt="" src="/image-16441@2x.png" />
      </div>
    </div>
    <section className="about-us-content-wrapper">
      <div className="about-us-content">
        <img
          className="about-us-content-child"
          loading="lazy"
          alt=""
          src={productCarousel}
        />
        <h1 className="about-us1">About Us</h1>
      </div>
    </section>
    <section className="about-us-paragraph-wrapper">
      <div className="about-us-paragraph">
        <div className="we-are-rapidqube">
          <h1 className="were-rapidqube">
            <span>We’re</span>
            <span className="rapidqube">{` Rapidqube  `}</span>
          </h1>
        </div>
        <div className="rapidqube-digital-is">
          RapidQube Digital is a disruptive, results-driven, next-gen IT
          services <br/> provider solving the modern digital challenges and
          assisting customers<br/> to adopt digital technologies with best-in-class
          services. We help <br/>accelerate digital transformation through the
          development and <br/>deployment of cutting-edge solutions applying the
          blockchain<br/> ecosystem along with IoT, Machine Learning (ML),
          Integration, And In The <br/>Omnichannel Space.
        </div>
      </div>
    </section>
    <MissionVision />
    <div className="our-timeline-wrapper">
      <h3 className="our-timeline">Our Timeline</h3>
    </div>
    <section className="transformative-tech">
      <h1 className="utilizing-transformative-techn">
        "Utilizing transformative<br/> technologies for sustainable <br/>solutions"
      </h1>
    </section>
    <FrameComponent />
    <div className="leadership-team-wrapper">
      <b className="leadership-team">Leadership Team</b>
    </div>
    <section className="leadership-description">
      <div className="delivering-solutions-leveragin">
        Delivering solutions leveraging “best in class” digital technology to
        enhance <br/> your business Delivering solutions leveraging “best in class”
        digital technology<br/> to enhance your business
      </div>
    </section>
    <Leadership/>
    <Footer />
  </div>
  );
};

export default AboutUs;
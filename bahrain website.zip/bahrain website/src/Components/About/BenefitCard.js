import { useMemo } from "react";
import PropTypes from "prop-types";
import "./BenefitCard.css";

const BenefitCard = ({
  className = "",
  engagementSeparator,
  engagement,
  establishedDevelopmentCen,
  stBlockchainProjectForIns,
  stOverseasBlockchainProje,
  stPOCForMaharashtraGovern,
  pOCForLegalHealthCarePubl,
  propFlex,
  propAlignSelf,
  propTop,
  propLeft,
  propHeight,
  propDisplay,
}) => {
  const benefitCard1Style = useMemo(() => {
    return {
      flex: propFlex,
      alignSelf: propAlignSelf,
    };
  }, [propFlex, propAlignSelf]);

  const engagementSeparatorStyle = useMemo(() => {
    return {
      top: propTop,
      left: propLeft,
    };
  }, [propTop, propLeft]);

  const establishedDevelopmentCenterContainerStyle = useMemo(() => {
    return {
      height: propHeight,
      display: propDisplay,
    };
  }, [propHeight, propDisplay]);

  return (
    <div className={`benefit-card1 ${className}`} style={benefitCard1Style}>
      <div className="card-number1">
        <div className="card-number-item" />
        <div className="engagement-separator" style={engagementSeparatorStyle}>
          {engagementSeparator}
        </div>
      </div>
      <b className="engagement">{engagement}</b>
      <p
        className="established-development-center-container"
        style={establishedDevelopmentCenterContainerStyle}
      >
        <ul className="established-development-center">
          <li className="established-development-center1">
            {establishedDevelopmentCen}
          </li>
          <li className="st-blockchain-project">{stBlockchainProjectForIns}</li>
          <li className="st-overseas-blockchain">
            {stOverseasBlockchainProje}
          </li>
          <li className="st-poc-for">{stPOCForMaharashtraGovern}</li>
          <li>{pOCForLegalHealthCarePubl}</li>
        </ul>
      </p>
    </div>
  );
};

BenefitCard.propTypes = {
  className: PropTypes.string,
  engagementSeparator: PropTypes.string,
  engagement: PropTypes.string,
  establishedDevelopmentCen: PropTypes.string,
  stBlockchainProjectForIns: PropTypes.string,
  stOverseasBlockchainProje: PropTypes.string,
  stPOCForMaharashtraGovern: PropTypes.string,
  pOCForLegalHealthCarePubl: PropTypes.string,

  /** Style props */
  propFlex: PropTypes.any,
  propAlignSelf: PropTypes.any,
  propTop: PropTypes.any,
  propLeft: PropTypes.any,
  propHeight: PropTypes.any,
  propDisplay: PropTypes.any,
};

export default BenefitCard;
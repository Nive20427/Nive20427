import React from 'react'



function Home() {
  return (
    <div className='main-content'>  
        <div className='Hero'>
      <h1 className='Hero-title'>
        Software Development <br /> for  Business Growth
      </h1>
      <p className="hero-description">
        Delivering Solutions Leveraging "Best In Class"
        </p>
      <p className="hero-description">
        Digital Technology To Enhance your Business
        </p>
        <div className="hero-buttons">
        <button className="btn btn-success hero-btn">Start Free Trial</button>
        <button className="btn hero-btn-outline">Learn More</button>
      </div>
    </div>
    </div>

  )
}

export default Home;


import React from 'react';
import './Testimonials.css';
import TestimonialMenImg from '../assests/TestimonialMenImg.jpg'
const testimonials = [
  {
    id: 1,
    name: "Jane Cooper",
    title: "Marketing Coordinator",
    text: "Ask CDCR San Quintin State Prison 2008. We installed Purex dispensers throughout the prison to combat diseases...and it was a Roaring Success (as in Roaring Drunk) I mean we had long lines of prisoners fist fighting to use them.",
    image: {TestimonialMenImg}
  },
  {
    id: 2,
    name: "Jane Cooper",
    title: "Marketing Coordinator",
    text: "Ask CDCR San Quintin State Prison 2008. We installed Purex dispensers throughout the prison to combat diseases...and it was a Roaring Success (as in Roaring Drunk) I mean we had long lines of prisoners fist fighting to use them.",
    image: {TestimonialMenImg}
  },
  {
    id: 3,
    name: "Jane Cooper",
    title: "Marketing Coordinator",
    text: "Ask CDCR San Quintin State Prison 2008. We installed Purex dispensers throughout the prison to combat diseases...and it was a Roaring Success (as in Roaring Drunk) I mean we had long lines of prisoners fist fighting to use them.",
    image: {TestimonialMenImg}
  }
];

function Testimonials() {
  return (
    <div className="testimonials-section container-fluid">
      <h2 className="section-title" >What Our Client Says</h2>
      <p className="section-subtitle">
        Delivering Solutions Leveraging “Best In Class” Digital Technology To Enhance Your Business
      </p>
      <div className="row justify-content-center">
        {testimonials.map((testimonial) => (
          <div key={testimonial.id} className="col-md-4 testimonial-card">
            <div className="card">
              <div className="card-body">
                <div className="testimonial-header">
                  <img src={TestimonialMenImg} alt={testimonial.name} className="testimonial-image" />
                  <div className="testimonial-info">
                    <h5 className="testimonial-name">{testimonial.name}</h5>
                    <p className="testimonial-title">{testimonial.title}</p>
                  </div>
                </div>
                <p className="testimonial-text">{testimonial.text}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
      <div className="carousel-controls d-flex justify-content-end md-4">
            <button className="prev-btn btn btn-outline-success">
              &lt;
            </button>
            <button className="next-btn btn btn-outline-success">
              &gt;
            </button>
          </div>
    </div>
  );
}

export default Testimonials;
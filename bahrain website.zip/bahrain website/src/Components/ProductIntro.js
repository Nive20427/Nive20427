import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
// import sampleImage from '../path/to/your/image.jpg';

function ProductIntro() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [hoverIndex, setHoverIndex] = useState(null);

  const handlePrevClick = () => {
    setCurrentIndex((prevIndex) => (prevIndex === 0 ? 0 : prevIndex - 1));
  };

  const handleNextClick = () => {
    setCurrentIndex((prevIndex) => (prevIndex === productSections.length - 5 ? prevIndex : prevIndex + 1));
  };

  const handleMouseEnter = (index) => {
    setHoverIndex(index);
  };

  const handleMouseLeave = () => {
    setHoverIndex(null);
  };

  const productSections = [
    { id: 1, title: 'Digital & Software', description: 'Natural Language Processing (NLP) is a technology that helps machines understand and interpret human language.' },
    { id: 2, title: 'Digital & Software', description: 'Natural Language Processing (NLP) is a technology that helps machines understand and interpret human language.' },
    { id: 3, title: 'Digital & Software', description: 'Natural Language Processing (NLP) is a technology that helps machines understand and interpret human language.' },
    { id: 4, title: 'Digital & Software', description: 'Natural Language Processing (NLP) is a technology that helps machines understand and interpret human language.' },
    { id: 5, title: 'Digital & Software', description: 'Natural Language Processing (NLP) is a technology that helps machines understand and interpret human language.' },
    { id: 6, title: 'Digital & Software', description: 'Natural Language Processing (NLP) is a technology that helps machines understand and interpret human language.' },
  ];

  return (
    <div className="product-intro-section">
      <div className="product-intro-inner-section container">
        <div className="product-intro-content">
          <h3 className="product-intro-heading">Featured Products</h3>
          <p>Delivering Solutions Leveraging "Best in Class"</p>
          <p>Delivering Technology To Enhance Your Business</p>          <p>Delivering</p>
        </div>
        <div className="product-list-section">
          <div className="list-of-products d-flex flex-wrap">
            {productSections.slice(currentIndex, currentIndex + 5).map((section, index) => (
              <div 
                key={section.id} 
                className={`product-section flex-grow-1 ${hoverIndex === index ? 'hover' : ''}`}
                onMouseEnter={() => handleMouseEnter(index)}
                onMouseLeave={handleMouseLeave}
              >
                <h6>{section.title}</h6>
                <p>{section.description}</p>
                {hoverIndex === index && (
                  <div>
                    <div className="image-container">
                      <img src="#" alt={section.title} className="product-image" />
                    </div>
                    <button className="view-product-btn">View Product</button>
                  </div>
                )}
              </div>
            ))}
          </div>
          <div className="carousel-controls d-flex justify-content-end mt-3">
            <button className="prev-btn btn btn-outline-success" onClick={handlePrevClick}>
              &lt;
            </button>
            <button className="next-btn btn btn-outline-success" onClick={handleNextClick}>
              &gt;
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ProductIntro;


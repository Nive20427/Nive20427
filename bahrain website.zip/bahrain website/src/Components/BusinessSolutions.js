import React from 'react';
import './BusinessSolutions.css';
import { FaLaptop, FaUserTie, FaChartLine } from 'react-icons/fa';

const services = [
  {
    id: 1,
    icon: <FaLaptop />,
    years: "8+ Years",
    description: `Gen AI is a cutting-edge platform that harnesses the power of artificial intelligence to produce a wide range of creative text.`
  },
  {
    id: 2,
    icon: <FaUserTie />,
    years: "50+ Experts",
    description: "Gen AI is a cutting-edge platform that harnesses the power of artificial intelligence to produce a wide range of creative text."
  },
  {
    id: 3,
    icon: <FaChartLine />,
    years: "8+ Years",
    description: "Gen AI is a cutting-edge platform that harnesses the power of artificial intelligence to produce a wide range of creative text."
  }
];

function BusinessSolutions() {
  return (
    <div className="business-solutions-section">
      <div className="container">
        <h2 className="main-title text-center">Empower Your Business with Access to World-Class Products,<br /> Services, and Solutions</h2>
        <p className="subtitle text-center">
          Delivering Solutions Leveraging “Best In Class” Digital Technology To Enhance Your Business
        </p>
        <p className="subtitle text-center">
          Business Delivering Solutions "Best In Class" Digital Technology To <br />Enhance Your Business
        </p>
        <div className="row">
          {services.map((service) => (
            <div key={service.id} className="col-md-4 service-card">
              <div className="card h-100">
                <div className="card-body">
                  <div className="icon">{service.icon}</div>
                  <h5 className="years">{service.years}</h5>
                  <p className="description">{service.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default BusinessSolutions;
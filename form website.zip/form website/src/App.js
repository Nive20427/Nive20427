import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Form from './components/Form';
import Table from './components/Table.js';


const App = () => {
  const [showForm, setShowForm] = useState(false);
  const [users, setUsers] = useState([]);
  const [editing, setEditing] = useState(false);
  const [selectedUser, setSelectedUser] = useState(null);
  const [editingRow, setEditingRow] = useState(null);
  const [editingMode, setEditingMode] = useState(false);



  const fetchUsers = async () => {
    try {
      const response = await axios.get('http://localhost:9000/users');
      setUsers(response.data);
    } catch (error) {
      console.error('Error fetching users:', error);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const handleSubmit = async (newUser) => {
    setShowForm(false);
  };

  const handleGoBack = () => {
    setShowForm(true);
  };

  const handleSave = async (id, updatedUser) => {
    console.log(id, updatedUser)
    //  let data =JSON.stringfy()
    await axios.put(`http://localhost:9000/users/${id}`, updatedUser).then((res) => { console.log("res", res) })
    setEditingMode(false)
    fetchUsers();

  };
  const handleDelete = async (id) => {
    console.log(id)
    try {
      const response = await axios.delete(`http://localhost:9000/users/${id}`);
      console.log("response_", response);
      fetchUsers();
    } catch (error) {
      console.error('Error updating user:', error);
    }
  }
  return (
    <div className="container">
      <div className="row justify-content-center">
        <div className="col-md-8">
          <div className="mt-5 card-header">
            <h2>Registration Form</h2>
          </div>
          {showForm ?
            <Form onSubmit={handleSubmit} />
            :
            <div>
              <h2>Registered Users</h2>
              <Table data={users} handleDelete={handleDelete} setUsers={setUsers}
                handleSave={handleSave} setEditingRow={setEditingRow} editingRow={editingRow} editingMode={editingMode} setEditingMode={setEditingMode} />
              <button className="btn btn-primary mt-3" onClick={handleGoBack}>
                Go Back
              </button>
            </div>
          }
        </div>

      </div>
    </div>
  );
};
export default App;

// import React, { useState, useEffect } from 'react';
// import axios from 'axios';
// import Form from './components/Form';
// import Table from './components/Table';

// const App = () => {
//   const [users, setUsers] = useState([]);

//   useEffect(() => {
//     fetchUsers();
//   }, []);

//   const fetchUsers = async () => {
//     try {
//       const response = await axios.get('http://localhost:9000/users');
//       setUsers(response.data);
//     } catch (error) {
//       console.error('Error fetching users:', error);
//     }
//   };

//   const addUser = (newUser) => {
//     setUsers([...users, newUser]);
//   };

//   const updateUser = async (id) => {

//       try {
//         await axios.put(`http://localhost:9000/users${id}`, { name: updatedUser });
//         fetchUsers();
//       } catch (error) {
//         console.error('Error updating user:', error);
//       }
//     }
//   };

//   const deleteUser = async (id) => {
//     try {
//       await axios.delete(`http://localhost:9000/users/${id}`);
//       fetchUsers();
//     } catch (error) {
//       console.error('Error deleting user:', error);
//     }
//   };

//   return (
//     <div className="container mt-5">
//       <h1 className="mb-4">Registration Form</h1>
//       <Form addUser={addUser} />
//       <h2 className="mt-5">Registered Users</h2>
//       <Table users={users} updateUser={updateUser} deleteUser={deleteUser} />
//     </div>
//   );
// };

// export default App;

// import React, { useState } from 'react';
// import axios from 'axios';
// import RegistrationForm from './RegistrationForm';
// import Table from './Table';

// const App = () => {
//   const [showTable, setShowTable] = useState(false);
//   const [users, setUsers] = useState([]);

//   const handleSubmit = (newUser) => {
//     setUsers([...users, newUser]);
//     setShowTable(true);
//   };

//   const handleGoBack = () => {
//     setShowTable(false);
//   };

//   return (
//     <div className="container mt-5">
//       <h1 className="mb-4">Registration Form</h1>
//       {showTable ? (
//         <Table
//           users={users}
//           onUpdate={handleUpdate}
//           onDelete={handleDelete}
//           onGoBack={handleGoBack}
//         />
//       ) : (
//         <RegistrationForm onSubmit={handleSubmit} />
//       )}
//     </div>
//   );
// };

//  export default App;
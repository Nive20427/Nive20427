import React, { useState } from 'react';
import axios from 'axios';
import './Table.css';
import '../App.css';



const Form = ({ onSubmit }) => {
  const [formData, setFormData] = useState({
    id: '',
    symbol: '',
    name: '',
    last: '',
    change: '',
    changePercent: '',
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    let id = []
    let finalData = [{ ...formData }]
    let getData = await axios.get('http://localhost:9000/users')
    let lastId = getData.data.length       //
    let nextID = Math.max((lastId + 1))    // using for id auto generate 
    finalData[0].id = nextID               //

    let sendingdata = finalData[0]
    console.log(sendingdata);
    // return
    try {
      const response = await axios.post('http://localhost:9000/users', sendingdata);
      onSubmit();
      setFormData({
       
        symbol: '',
        name: '',
        last: '',
        change: '',
        changePercent: '',
      });
    } catch (error) {
      console.error('Error submitting form:', error);
    }
  };

  return (
    <div className='form_container'>
      <form onSubmit={handleSubmit}>
        {/*// <div className="form-group">
        //   <label htmlFor="id" >ID</label>
        //   <input
          //   type="text"
          //   className="form-control"
          //   id="id"
          //   name="id"
          //   value={formData.id}
          //   placeholder='Enter the ID' required
          //   onChange={handleChange}
          // />
  </div>*/}
        <div className="form-group">
          <label htmlFor="symbol">Symbol</label>
          <input
            type="text"
            className="form-control"
            id={"symbol"}
            name="symbol"
            value={formData.symbol}
            placeholder='Enter the symbol' required
            onChange={handleChange}
          />
        </div>
        <div className="form-group">
          <label htmlFor="name">Name</label>
          <input
            type="text"
            className="form-control"
            id="name"
            name="name"
            value={formData.name}
            placeholder='Enter the name' required
            onChange={handleChange}
          />
        </div>
        <div className="form-group">
          <label htmlFor="last">Last</label>
          <input
            type="text"
            className="form-control"
            id="last"
            name="last"
            value={formData.last}
            placeholder='Enter the lastname' required
            onChange={handleChange}
          />
        </div>
        <div className="form-group">
          <label htmlFor="change">Change</label>
          <input
            type="text"
            className="form-control"
            id="change"
            name="change"
            value={formData.change}
            placeholder='Enter the change' required
            onChange={handleChange}
          />
        </div>
        <div className="form-group">
          <label htmlFor="changePercent">Change Percent</label>
          <input
            type="text"
            className="form-control"
            id="changePercent"
            name="changePercent"
            value={formData.changePercent}
            placeholder='Enter the changepercent' required
            onChange={handleChange}
          />
        </div>
        <div className='btn'>
          <button type="submit" className="btn btn-primary">
            Submit
          </button>
        </div>
      </form>
    </div>

  );
};

export default Form;

    





// import React, { useState } from 'react';
// import axios from 'axios';

// const Form = ({ addUser }) => {
//   const [formData, setFormData] = useState({
//     id: '',
//     name: '',
//     email: '',
//   });

//   const handleChange = (e) => {
//     setFormData({ ...formData, [e.target.name]: e.target.value });
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     try {
//       const response = await axios.post('http://localhost:5000/users', formData);
//       addUser(response.data);
//       setFormData({
//         id: '',
//         name: '',
//         email: '',
//       });
//     } catch (error) {
//       console.error('Error submitting form:', error);
//     }
//   };

//   return (
//     <form onSubmit={handleSubmit}>
//       <div className="mb-3">
//         <label className="form-label">Name</label>
//         <input
//           type="text"
//           className="form-control"
//           name="name"
//           value={formData.name}
//           onChange={handleChange}
//         />
//       </div>
//       <div className="mb-3">
//         <label className="form-label">Email</label>
//         <input
//           type="email"
//           className="form-control"
//           name="email"
//           value={formData.email}
//           onChange={handleChange}
//         />
//       </div>
//       <button type="submit" className="btn btn-primary">Submit</button>
//     </form>
//   );
// };

// export default Form;




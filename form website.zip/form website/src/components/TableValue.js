import React, { useState } from 'react';

const TableValue= ({ user, handleUpdate, handleDelete }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editedUser, setEditedUser] = useState(user);

  const handleChange = (e) => {
    setEditedUser({ ...editedUser, [e.target.name]: e.target.value });
  };

  const handleSaveUpdate = () => {
    handleUpdate(editedUser);
    setIsEditing(false);
  };

  const handleCancelUpdate = () => {
    setIsEditing(false);
    setEditedUser(user);
  };

  return (
    <tr>
      {isEditing ? (
        <div>
          <td>
            <input
              type="text"
              name="id"
              value={editedUser.id}
              onChange={handleChange}
            />
          </td>
          <td>
            <input
              type="text"
              name="symbol"
              value={editedUser.symbol}
              onChange={handleChange}
            />
          </td>
          <td>
            <input
              type="text"
              name="name"
              value={editedUser.name}
              onChange={handleChange}
            />
          </td>
          <td>
            <input
              type="text"
              name="last"
              value={editedUser.last}
              onChange={handleChange}
            />
          </td>
          <td>
            <input
              type="text"
              name="change"
              value={editedUser.change}
              onChange={handleChange}
            />
          </td>
          <td>
            <input
              type="text"
              name="changePercent"
              value={editedUser.changePercent}
              onChange={handleChange}
            />
          </td>
          <td>
            <button className='btn btn-success' onClick={handleSaveUpdate}>Save</button>
            <button className='btn btn-success' onClick={handleCancelUpdate}>Cancel</button>
          </td>
        </div>
      ) : (
        <div>
          <td>{user.id}</td>
          <td>{user.symbol}</td>
          <td>{user.name}</td>
          <td>{user.last}</td>
          <td>{user.change}</td>
          <td>{user.changePercent}</td>
          <td>
            <button className="btn btn-primary" onClick={() => setIsEditing(true)}>Update</button>
            <button className="btn btn-danger" onClick={() => handleDelete(" ")}>Delete</button>
          </td>
        </div>
      )}    
    </tr>
  );
};

export default TableValue;
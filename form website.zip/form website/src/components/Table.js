import React, { useState } from 'react';

const Table = ({ data, handleSave, handleDelete, setUsers ,editingRow, setEditingRow,fetchUsers,editingMode, setEditingMode}) => {
  // const [editingMode, setEditingMode] = useState(false);

  const [updatedValues, setUpdatedValues] = useState({});
  const [symbol, setSymbol] = useState('')
  const [name, setName] = useState('')
  const [last, setLast] = useState('')
  const [change, setChange] = useState('')
  const [changePercent, setChangePercent] = useState('')
  const [finaleEditdata, setFinaleditdata] = useState([])


  const handleInputUpdate = (e, id, field) => {
    // setUpdatedValues((prevValues) => ({
    //   ...prevValues,
    //   [id]: {
    //     ...prevValues[id],
    //     [field]: e.target.value,
    //   },
    // }));

  };
  const handleCanceledit = () => {
    setEditingMode(false)
    setEditingRow(null)
    setUpdatedValues({})
    setFinaleditdata([])
  }
  const handleChange = (e, id) => {
    console.log(e.target.value, id)

    let asd = e.target.value;
    console.log("asd", asd)
    setUsers({ ...data, [e.target.id]: asd })
  }
  const handleEdit = (id) => {
    setEditingRow(id);
    setEditingMode(true)

    const editData = data.filter(data => data.id == id)
    //  console.log(editData);
    setFinaleditdata({ id:editData[0].id,symbol: editData[0].symbol, name: editData[0].name, last: editData[0].last, change: editData[0].change, changePercent: editData[0].changePercent })

    return
    setUpdatedValues((prevValues) => ({
      ...prevValues,
      [id]: data.find((user) => user.id === id),
    }));
  };

  // const handleSave = (id, updatedUser) => {
  //   try {
  //     axios.put(`http://localhost:9000/users/${id}`, updatedUser)
  //       .then(response => {
  //         setData(prevData => prevData.map(row => row.id === id ? { ...row, ...updatedUser } : row));
  //       })
  //       .catch(error => {
  //         console.error('Error updating user:', error);
  //       });
  //   } catch (error) {
  //     console.error('Error updating user:', error);
  //   }
  // }


  console.log(finaleEditdata)

  return (
    <table className="table table-striped">
      <thead>
        <tr>
          <th>ID</th>
          <th>Symbol</th>
          <th>Name</th>
          <th>Last</th>
          <th>Change</th>
          <th>Change Percent</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        {data.map((user) => (
          <tr key={user.id}>
            <td>{user.id}</td>
            {editingMode && editingRow == user.id ? <td><input id='symbol' value={finaleEditdata.symbol} onChange={(e) => setFinaleditdata({ ...finaleEditdata, symbol: e.target.value })} /> </td> : <td>
              {user.symbol}
            </td>}

            {editingMode && editingRow == user.id ? <td><input id={'name'} value={finaleEditdata.name} onChange={(e) => setFinaleditdata({ ...finaleEditdata, name: e.target.value })} /> </td> : <td>
              {user.name}
            </td>}

            {editingMode && editingRow == user.id ? <td><input id={'last'} value={finaleEditdata.last} onChange={(e) => setFinaleditdata({ ...finaleEditdata, last: e.target.value })} /></td> : <td>
              {user.last}
            </td>}

            {editingMode && editingRow == user.id ? <td><input id={"change"} value={finaleEditdata.change} onChange={(e) => setFinaleditdata({ ...finaleEditdata, change: e.target.value })} /> </td> : <td>
              {user.change}
            </td>}

            {editingMode && editingRow == user.id ? <td><input id={"changePercent"} value={finaleEditdata.changePercent} onChange={(e) => setFinaleditdata({ ...finaleEditdata, changePercent: e.target.value })} /> </td> : <td>
              {user.changePercent}
            </td>}
            <td>
              {editingMode ? <button className="btn btn-success mr-2" onClick={() => handleCanceledit(user.id)} > Cancel Edit</button>
                : <button className="btn btn-primary" id={user.id} onClick={() => handleEdit(user.id)}>Edit</button>}
              {editingMode && <button className="btn btn-success mr-2" onClick={() => handleSave(user.id, finaleEditdata)} >Save</button>}
              <button className="btn btn-danger" onClick={() => handleDelete(user.id)}>Delete</button>
            </td>
          </tr>

        ))}
      </tbody>
    </table>
  );
};

export default Table;



// import React from 'react';

// const Table = ({ users, onUpdate, onDelete, onGoBack }) => {
//   return (
//     <div>
//       <button className="btn btn-primary" onClick={onGoBack}>Go Back</button>
//       <table className="table table-striped mt-3">
//         <thead>
//           <tr>
//             <th>Name</th>
//             <th>Email</th>
//             <th>Actions</th>
//           </tr>
//         </thead>
//         <tbody>
//           {users.map((user) => (
//             <tr key={user.id}>
//               <td>{user.name}</td>
//               <td>{user.email}</td>
//               <td>
//                 <button className="btn btn-primary" onClick={() => onUpdate(user)}>Update</button>
//                 <button className="btn btn-danger" onClick={() => onDelete(user.id)}>Delete</button>
//               </td>
//             </tr>
//           ))}
//         </tbody>
//       </table>
//     </div>
//   );
// };

// export default Table;

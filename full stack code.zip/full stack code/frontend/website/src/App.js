import React from 'react';
import { Route, Routes, Link , Navigate } from "react-router-dom";
import { useSelector } from 'react-redux';
import './App.css';
import Home from './pages/home/Home';
import Login from './pages/login/Login';
import Profile from './pages/profile/Profile';
import Forgotpassword from './pages/forgotpassword/ForgotPassword';
import Resetpassword from './pages/resetPassword/ResetPassword';
import Signup from './pages/register/Signup';
import Verifyemail from './pages/verifymail/Verifymail';


function App () {

  const userDetails = useSelector((state)=>state.user);
  let user = userDetails?.user

  return (
    <div className="App"> 
    <nav>
      <div style={{backgroundImage:'url("https://images.pexels.com/photos/1831234/pexels-photo-1831234.jpeg?auto=compress&cs=tinysrgb&w=600")'}}>
        <ul style={{display: 'flex',  justifyContent: 'space-between', paddingTop:20   }}>

          <Link to="/" elements={ user?.other?.verifed === true ? <Home /> : <Navigate to={"/login"} replace={true}/>} className="list">
            Sign In
          </Link>
          <Link to="/Profile/:id" elements={<Profile />} className="list">
            Profile 
          </Link>
          <Link to="/Login" elements={user?.other?.verifed === true ? <Navigate to={"/"} replace={true}/> : <Login />} className="list">
            Login
          </Link>
          <Link to="/SignuP" elements={<signup/>} className="list">
            Sign Up
          </Link>
          <Link to="/verify/email"  element={user?.Status === 'Pending' ? <Verifyemail/> : user?.other?.verifed === true ? <Navigate to={"/"} replace={true}/> : <Login/>} className="list">
            Home
          </Link>
          <Link to="/forgot/password" elements={<Forgotpassword />} className="list">
            About
          </Link>
          <Link to="/reset/password" elements={<Resetpassword />} className="list">
            About
          </Link>
        </ul>
      </div>
    </nav>
    <Routes>
      <Route path="/" element={user?.other?.verifed === true ? <Home/> : <Navigate to={"/login"} replace={true}/>} />
      <Route path="/Profile/:id" element={<Profile />} />
      <Route path="/Login"  element={ user?.other?.verifed === true ? <Navigate to={"/"} replace={true}/> : <Login />} />
      <Route path="/Signup" element={<Signup />} />
      <Route path="/verify/email"  element={user?.Status === 'Pending' ? <Verifyemail/> : user?.other?.verifed === true ? <Navigate to={"/"} replace={true}/> : <Login/>} />
      <Route path="/forgot/password" element={<Forgotpassword />} />
      <Route path="/reset/password" element={<Resetpassword/>} />
  </Routes>
  </div>
  )
}

export default App


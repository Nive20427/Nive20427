import { initializeApp } from "firebase/app";

const firebaseConfig = {
  apiKey: "AIzaSyBXphSl7uRz6kqv8vVWPxVKyKYeHT4OB4k",
  authDomain: "social-media-9856b.firebaseapp.com",
  projectId: "social-media-9856b",
  storageBucket: "social-media-9856b.appspot.com",
  messagingSenderId: "496910700238",
  appId: "1:496910700238:web:c29cadb877d4d9a2d7ca9f"
};
const app = initializeApp(firebaseConfig);
export default app;
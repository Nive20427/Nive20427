
import React from 'react'
import { useSelector } from 'react-redux';
import Leftbar from '../../components/LeftsideContainer/LeftBar.js';
import MainPost from '../../components/MainPostContainer/MainPost.js';
import Navbar from '../../components/NavBar/NavBar.js';
import Rightbar from '../../components/RightSideContainer/Rightbar.js';
import './Home.css';
export default function Home() {
  const userDetails = useSelector((state)=>state.user);
  let user = userDetails.user
  console.log(user)
  return (
    <div className='home'>
          <Navbar/>
          <div className="ComponentContainer">
            <Leftbar/>
            <MainPost/>
            <Rightbar/>
          </div>
    </div>
  )
}
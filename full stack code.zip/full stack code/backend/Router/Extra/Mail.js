// export function generateOTP(){
//     let OTP = '';
//     for (let i = 0; i <= 3; i++) {
//               let ranVal = Math.round(Math.random()*9);
//               OTP = OTP+ranVal;
//     }
//     return OTP;
// }
// exports.generateOTP = generateOTP;

// function generateOTP() {
//     let otp = '';
//     const digits = '0123456789';
  
//     for (let i = 0; i < 4; i++) {
//       otp += digits[Math.floor(Math.random() * 10)];
//     }
  
// //     return otp;
// //   }
  
// //   exports.generateOTP = generateOTP;

// const { generateOTP } = require('./file');

// const myOTP = generateOTP();
// console.log(myOTP);
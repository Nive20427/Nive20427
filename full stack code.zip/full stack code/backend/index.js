// const express = require ('express')
// const mongoose = require('mongoose');

// const { MongoClient, ServerApiVersion } = require('mongodb');

// const app = express()

// app.get('/', (req, res) => {
//  res.send('server is ready')
// })

// const port = process.env.PORT || 8000

// app.listen(port, () => {
//     console.log (`server at http://localhost:${port}`) 
// }) 


// mongodb://localhost:27017 -url 

// const uri = "mongodb+srv://nivetha:<password>@cluster0.mjfb5cf.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";

// // Create a MongoClient with a MongoClientOptions object to set the Stable API version
// const client = new MongoClient(uri, {
//   serverApi: {
//     version: ServerApiVersion.v1,
//     strict: true,
//     deprecationErrors: true,
//   }
// });

// async function run() {
//   try {
//     // Connect the client to the server	(optional starting in v4.7)
//     await client.connect();
//     // Send a ping to confirm a successful connection
//     await client.db("admin").command({ ping: 1 });
//     console.log("Pinged your deployment. You successfully connected to MongoDB!");
//   } finally {
//     // Ensures that the client will close when you finish/error
//     await client.close();
//   }
// }
// run().catch(console.dir);



const express = require('express');
const app = express();
const mongoose = require('mongoose')
const dotenv = require('dotenv');
const userRouter = require("./Router/User");
const PostRouter = require("./Router/Post")
const cors = require("cors");
dotenv.config();


mongoose.connect(process.env.MONGODB).then(()=>
console.log("DB connection successfull")).catch(()=>{
          console.log("Some error occured")
})
app.use(cors());
app.use(express.json());
app.use("/api/user" , userRouter);
app.use("/api/post" , PostRouter )

app.listen(5000 , ()=>{
          console.log("Server is running")
})


//npm i cors
//npm i express-validator
//npm i nodemon
//npm i nodemailer
//npm i bcryptjs
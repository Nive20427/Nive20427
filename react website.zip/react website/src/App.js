import React from 'react';
import './App.css';
import { Route, Routes, NavLink } from "react-router-dom";
import Home from './navbar/Home';
import About from './navbar/About';
import Contact from './navbar/Contact';
import Help from './navbar/Help';
import LoginForm from './components/LoginForm';
import RegisterForm from './components/RegisterForm';
import Data from './navbar/Data';



function App() {

  return (
    <div className="App"> 
      <nav>
        <div style={{backgroundImage:'url("https://images.pexels.com/photos/1831234/pexels-photo-1831234.jpeg?auto=compress&cs=tinysrgb&w=600")'}}>
          <ul style={{display: 'flex',  justifyContent: 'space-between', paddingTop:20   }}>

            <NavLink to="/" elements={<LoginForm signup={false} />} className="list">
              Sign In
            </NavLink>
            <NavLink to="/SignUP" elements={<LoginForm signup={true} />} className="list">
              Sign Up
            </NavLink>
            <NavLink to="/home" elements={<Home />} className="list">
              Home
            </NavLink>
            <NavLink to="/about" elements={<About />} className="list">
              About
            </NavLink>
            <NavLink to="/contact" elements={<Contact />} className="list">
              Contact
            </NavLink>
            <NavLink to="/data" elements={<Data />} className="list">
            Data
          </NavLink>
            <NavLink to="/Help" elements={<Help />} className="list">
              Help
            </NavLink>


          </ul>
        </div>
      </nav>
      <Routes>
        <Route path="/" element={<LoginForm signup={false} />} />
        <Route path="/SignUP" element={<LoginForm signup={true} />} />

        <Route path="/home" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/data" element={<Data />} />
        <Route path="/help" element={<Help />} />
        <Route path="/register" element={<RegisterForm />} />

      </Routes>
    </div>
  );
}

export default App;



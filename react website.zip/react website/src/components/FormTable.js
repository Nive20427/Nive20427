import React, { useState } from 'react';

const FormTable = ({ data, handleSave, handleDelete, setUsers, editingRow, setEditingRow, fetchUsers, editingMode, setEditingMode }) => {
  // const [editingMode, setEditingMode] = useState(false);

  const [updatedValues, setUpdatedValues] = useState({});
  const [name, setSymbol] = useState('')
  const [email, setEmail] = useState('')
  const [phoneNumber, setLast] = useState('')
  const [age, setAge] = useState('')
  const [gender, setGender] = useState('')
  const [country, setcountry] = useState('')
  const [address, setAddress] = useState('')
  const [pincode, setPincode] = useState('')
  const [finaleEditdata, setFinaleditdata] = useState([])

  const handleCanceledit = () => {
    setEditingMode(false)
    setEditingRow(null)
    setUpdatedValues({})
    setFinaleditdata([])
  }
  const handleChange = (e, id) => {
    console.log(e.target.value, id)

    let asd = e.target.value;
    console.log("asd", asd)
    setUsers({ ...data, [e.target.id]: asd })
  }
  const handleEdit = (id) => {
    setEditingRow(id);
    setEditingMode(true)

    const editData = data.filter(data => data.id == id)
    //  console.log(editData);
    setFinaleditdata({
      id: editData[0].id, name: editData[0].name, email: editData[0].email, phoneNumber: editData[0].phoneNumber,
      age: editData[0].age, gender: editData[0].gender,
      country: editData[0].country, address: editData[0].address, pincode: editData[0].pincode
    })

    return
    setUpdatedValues((prevValues) => ({
      ...prevValues,
      [id]: data.find((user) => user.id === id),
    }));
  };
  console.log(finaleEditdata)

  return (
    <table className="table table-striped">
      <thead>
        <tr>
          <th>ID</th>
          <th>Symbol</th>
          <th>Name</th>
          <th>Age</th>
          <th>Gender</th>
          <th>Country</th>
          <th>Address</th>
          <th>Pincode</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        {data.map((user) => (
          <tr key={user.id}>
            <td>{user.id}</td>
            {editingMode && editingRow == user.id ? <td><input id='name' value={finaleEditdata.name} onChange={(e) => setFinaleditdata({ ...finaleEditdata, name: e.target.value })} /> </td> : <td>
              {user.name}
            </td>}

            {editingMode && editingRow == user.id ? <td><input id={'email'} value={finaleEditdata.email} onChange={(e) => setFinaleditdata({ ...finaleEditdata, email: e.target.value })} /> </td> : <td>
              {user.email}
            </td>}

            {editingMode && editingRow == user.id ? <td><input id={'phoneNumber'} value={finaleEditdata.phoneNumber} onChange={(e) => setFinaleditdata({ ...finaleEditdata, phoneNumber: e.target.value })} /></td> : <td>
              {user.phoneNumber}
            </td>}

            {editingMode && editingRow == user.id ? <td><input id={"age"} value={finaleEditdata.age} onChange={(e) => setFinaleditdata({ ...finaleEditdata, age: e.target.value })} /> </td> : <td>
              {user.age}
            </td>}

            {editingMode && editingRow == user.id ? <td><input id={"gender"} value={finaleEditdata.gender} onChange={(e) => setFinaleditdata({ ...finaleEditdata, gender: e.target.value })} /> </td> : <td>
              {user.gender}
            </td>}

            {editingMode && editingRow == user.id ? <td><input id={"country"} value={finaleEditdata.country} onChange={(e) => setFinaleditdata({ ...finaleEditdata, country: e.target.value })} /> </td> : <td>
              {user.country}
            </td>}

            {editingMode && editingRow == user.id ? <td><input id={"address"} value={finaleEditdata.address} onChange={(e) => setFinaleditdata({ ...finaleEditdata, address: e.target.value })} /> </td> : <td>
              {user.address}
            </td>}

            {editingMode && editingRow == user.id ? <td><input id={"pincode"} value={finaleEditdata.pincode} onChange={(e) => setFinaleditdata({ ...finaleEditdata, pincode: e.target.value })} /> </td> : <td>
              {user.pincode}
            </td>}
            <td>
              {editingMode && editingRow == user.id ? <button className="btn btn-success mr-2" onClick={() => handleCanceledit(user.id)} > Cancel Edit</button>
                : <button className="btn btn-primary" id={user.id} onClick={() => handleEdit(user.id)}>Edit</button>}
              {editingMode&& editingRow == user.id && <button className="btn btn-success mr-2" onClick={() => handleSave(user.id, finaleEditdata)} >Save</button>}
              <button className="btn btn-danger" onClick={() => handleDelete(user.id)}>Delete</button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
};

export default FormTable;
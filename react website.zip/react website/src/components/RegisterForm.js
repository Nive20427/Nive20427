import React, { useState } from 'react';
import axios from 'axios';
import './Register.css'; 
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';


const RegisterForm = ({ onSubmit }) => {
  const Navigate =useNavigate();

  const [formData, setFormData] = useState({
    id: '',
    name: '',
    email: '',
    phoneNumber: '',
    age: '',
    gender:'',
    country: '',
    address:'',
    pincode:''
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    // let id = []
    let finalData = [{ ...formData }]
    let getData = await axios.get('http://localhost:8000/userbio')
    let phoneNumberId = getData.data.length       //
    let nextID = Math.max((phoneNumberId + 1))    // using for id auto generate 
    finalData[0].id = nextID                      //

    let sendingdata = finalData[0]             
    console.log(sendingdata);
    // return
    try {
      const response = await axios.post('http://localhost:8000/userbio', sendingdata);
    if(response.status == 200||response.status == 201){
       toast.success ("Registration Successfull");
    }
      setFormData({

        name: '',
        email: '',
        phoneNumber: '',
        age: '',
        gender:'',
        country: '',
        address:'',
        pincode:''
      });
      Navigate('/')
    } catch (error) {
      console.error('Error submitting form:', error);
    }
  };

  return (
    <div className='whole_container' style={{ backgroundImage: "url('https://wallpapers.com/images/high/wise-network-map-on-glossy-surface-f8aes9qmp7eo3p16.webp')", backgroundSize: 'cover', backgroundRepeat: 'no-repeat', backgroundPosition: 'center' }}>
    <div className='form_container'>
      <form onSubmit={handleSubmit}>

        <div className="form-group">
          <label htmlFor="name">Name</label>
          <input
            type="text"
            className="form-control"
            id={"name"}
            name="name"
            value={formData.name}
            placeholder='Enter the name' required
            onChange={handleChange}
          />
        </div>
        <div className="form-group">
          <label htmlFor="Email">Email</label>
          <input
            type="text"
            className="form-control"
            id="email"
            name="email"
            value={formData.email}
            placeholder='Enter the email' required
            onChange={handleChange}
          />
        </div>
        <div className="form-group">
          <label htmlFor="phoneNumber">PhoneNumber</label>
          <input
            type="text"
            className="form-control"
            id="phoneNumber"
            name="phoneNumber"
            value={formData.phoneNumber}
            placeholder='Enter the phoneNumber' required
            onChange={handleChange}
          />
        </div>
        <div className="form-group">
          <label htmlFor="age">Age</label>
          <input
            type="text"
            className="form-control"
            id="age"
            name="age"
            value={formData.age}
            placeholder='Enter the age' required
            onChange={handleChange}
          />
        </div>
        <div className="form-group">
          <label htmlFor="gender">Gender</label>
          <select
            className="form-control"
            id="gender"
            name="gender"
            value={formData.gender}
            placeholder='Enter the gender' 
            onChange={handleChange}
            required
          >
            <option value="">Select Gender</option>
            <option value="male">Male</option>
            <option value="female">Female</option>
            <option value="other">Other</option>
          </select>
        </div>
        <div className="form-group">
          <label htmlFor="country"> Country</label>
          <input
            type="text"
            className="form-control"
            id="country"
            name="country"
            value={formData.country}
            placeholder='Enter the country' required
            onChange={handleChange}
          />
        </div>
        <div className="form-group">
          <label htmlFor="address">Address</label>
          <textarea
            className="form-control"
            id="address"
            name="address"
            value={formData.address}
            placeholder='Enter the address' 
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="pincode">Pincode</label>
          <input
            type="text"
            className="form-control"
            id="pincode"
            name="pincode"
            value={formData.pincode}
            placeholder='Enter the pincode ' 
            onChange={handleChange}
            required
          />
        </div>
        <div className='btn'>
          <button type="submit" className="btn btn-primary">
            Submit
          </button>
        </div>
      </form>
    </div>
    </div>
  );
};

export default RegisterForm;
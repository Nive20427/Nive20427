import React from 'react';

function AboutSlide ({ title, description, imageSrc, className })  {
  return (
    <div className={`carousel-item ${className}`}>
      <img src={imageSrc} className="d-block w-100" alt={title} />
      <div className="carousel-caption">
        <h3>{title}</h3>
        <p>{description}</p>
      </div>
    </div>
    
  );
};

export default AboutSlide;
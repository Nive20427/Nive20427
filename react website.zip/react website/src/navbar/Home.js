import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faLaptopCode, faServer, faChartLine } from '@fortawesome/free-solid-svg-icons';
import './Home.css';
// import RegisterForm from '../components/RegisterForm';
import { useNavigate } from 'react-router-dom';



function Home() {
  const Navigate = useNavigate();

  const handleClick = () => {
    Navigate('/register')

  }
  return (
    <div className="homepage">
      <div className="hero-section">
        <div className="container">
          <div className="row">
            <div className="col-md-6">
              <h1>Welcome to Our Website</h1>
              <p>Discover innovative solutions for your business.</p>
              <button className="btn btn-primary">Learn More</button>
            </div>
          </div>
        </div>
      </div>
      <div className='d-flex justify-content-center'>
        <button className='btn btn-primary' onClick={handleClick}>Submit your Details</button>
      </div>

      <div className="features-section">
        <div className="container">
          <h2 className="text-center mb-5">Our Features</h2>
          <div className="row">
            <div className="col-md-4 mb-4">
              <div className="card h-100">
                <div className="card-body">
                  <FontAwesomeIcon icon={faLaptopCode} size="3x" className="mb-3" />
                  <h5 className="card-title">Web Development</h5>
                  <p className="card-text">Create engaging and responsive websites tailored to your needs.</p>
                </div>
              </div>

            </div>
            <div className="col-md-4 mb-4">
              <div className="card h-100">
                <div className="card-body">
                  <FontAwesomeIcon icon={faServer} size="3x" className="mb-3" />
                  <h5 className="card-title">Server Management</h5>
                  <p className="card-text">Reliable and secure hosting solutions for your applications.</p>
                </div>
              </div>
            </div>
            <div className="col-md-4 mb-4">
              <div className="card h-100">
                <div className="card-body">
                  <FontAwesomeIcon icon={faChartLine} size="3x" className="mb-3" />
                  <h5 className="card-title">Data Analytics</h5>
                  <p className="card-text">Gain valuable insights from your data with our advanced analytics tools.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;
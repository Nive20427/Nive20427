import React from 'react';
import { FaFacebook, FaTwitter, FaInstagram, FaLinkedin, FaYoutube } from 'react-icons/fa';

const Footer = () => {
  return (
    <footer className="bg-dark text-white py-4">
      <div className="container">
        <div className="row">
          <div className="col-md-6">
            <h5>About Us</h5>
            <p>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed auctor, magna non bibendum tincidunt, nunc augue sollicitudin ligula, a pulvinar nunc mauris at ante.
            </p>
          </div>
          <div className="col-md-6">
            <h5>Follow Us</h5>
            <div className="d-flex justify-content-end">
              <a href="https://www.facebook.com/" className="mx-2 text-white">
                <FaFacebook />
              </a>
              <a href="https://twitter.com/i/flow/login" className="mx-2 text-white">
                <FaTwitter />
              </a>
              <a href="https://www.instagram.com/" className="mx-2 text-white">
                <FaInstagram />
              </a>
              <a href="https://in.linkedin.com/" className="mx-2 text-white">
                <FaLinkedin />
              </a>
              <a href="https://www.youtube.com/" className="mx-2 text-white">
                <FaYoutube />
              </a>
            </div>
          </div>
        </div>
        <hr className="my-4" />
        <div className="row">
          <div className="col-12 text-center">
            <p>&copy; 2023 Your Company. All rights reserved.</p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
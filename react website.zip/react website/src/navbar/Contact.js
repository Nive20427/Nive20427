import React, { useState } from 'react';
import styles from './styles.css';

const Contact = () => {
  const [selectedLocation, setSelectedLocation] = useState(null);

  const locations = [
    {
      name: 'Chennai',
      address: '123 Main Street, Chennai, India',
      backgroundImage: 'url("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT7goRUITMW00lWbj0J0j-14VwwK8SaWwYKBw&s")',
    },
    {
      name: 'Mumbai',
      address: '456 Oak Avenue, Mumbai, India',
      backgroundImage: 'url("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTjeSS7Tg7sIUM3lgvDtHowqmP4b9M77r1aLg&s")',
    },
    {
      name: 'USA',
      address: '789 Elm Street, New York, USA',
      backgroundImage: 'url("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRM_SWSVkbXN9g1CpamoAPzO1qADYkzCzcnhw&s")',
    },
  ];

  const handleLocationClick = (location) => {
    setSelectedLocation(location);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
 
    console.log('Form submitted');
  };

  return (
    <div className={`${styles.container} row`} style={{ backgroundImage: 'url("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTEVqwOJQ9C858ngEZYAA1u9aT99AEXfy4RVg&s")' , backgroundSize: 'cover', backgroundRepeat: 'no-repeat', backgroundPosition: 'center', height:'100vh'}}>
      <div className={`${styles.leftColumn} col-md-4`}>
        <h3 className={styles.locationHeading}  style={{color:'yellowgreen'}}>Let's Keep in Touch</h3>
        <div className={styles.locationCards}>
          {locations.map((location, index) => (
            <div
              key={index}
              className={`card ${styles.locationCard} ${
                selectedLocation === location ? styles.active : ''
              }`}
              onClick={() => handleLocationClick(location)}
              style={{ backgroundImage: location.backgroundImage }}
            >
              <div className="card-body">
                <h5 className="card-title">{location.name}</h5>
              </div>
            </div>
          ))}
        </div>
        {selectedLocation && (
          <div className={styles.addressCard}>
            <div className="card">
              <div className="card-body">
                <h5 className="card-title">{selectedLocation.name}</h5>
                <p className="card-text">{selectedLocation.address}</p>
              </div>
            </div>
          </div>
        )}
      </div>
 
      <div className={`${styles.rightColumn} col-md-8`}>
        <h2>Get in Touch</h2>
        <form onSubmit={handleSubmit}>
          <div className="mb-3">
            <label htmlFor="name" className="form-label">
              Name
            </label>
            <input type="text" className="form-control" id="name" required />
          </div>
          <div className="mb-3">
            <label htmlFor="email" className="form-label">
              Email
            </label>
            <input type="email" className="form-control" id="email" required />
          </div>
          <div className="mb-3">
            <label htmlFor="phone" className="form-label">
              Phone Number
            </label>
            <input type="tel" className="form-control" id="phone" required />
          </div>
          <button type="submit" className="btn btn-primary">
            Submit
          </button>
        </form>
      </div>
    </div>
  );
};

export default Contact;
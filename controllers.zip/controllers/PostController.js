
import CommentsModels from "../models/commentsModels.js";
import PostModel from "../models/postModel.js";

import UserModel from "../models/userModel.js";
import mongoose from "mongoose";
import { uuid } from 'uuidv4';
import pkg from 'uuidv4';
// creating a post 
const { uuidv4 } = pkg;

const commentSchema = new mongoose.Schema({
  text: {
    type: String,
    required: true,
  },
  userId: {
    type: String,
    required: true,
  },
  commentId: {
    type: String,
    required: true,
  },
});


// const comment = mongoose.model('Comment', commentSchema);

export const createPost = async (req, res) => {
  const newPost = new PostModel(req.body);


  try {
    await newPost.save();
    res.status(200).json(newPost);
  } catch (error) {
    res.status(500).json(error);
  }
};

// get a post

export const getPost = async (req, res) => {
  const id = req.params.id;
  console.log("post id", id);
  try {
    const currentUserPosts = await PostModel.find({ userId: userId });
    console.log("49",currentUserPosts);
    const post = await PostModel.findById(id);
    res.status(200).json(post);
  } catch (error) {
    res.status(500).json(error);
  }
};

// update post
export const updatePost = async (req, res) => {
  const postId = req.params.id;
  const { userId } = req.body;

  try {
    const post = await PostModel.findById(postId);
    if (post.userId === userId) {
      await post.updateOne({ $set: req.body });
      res.status(200).json("Post updated!");
    } else {
      res.status(403).json("Authentication failed");
    }
  } catch (error) { }
};

// delete a post
export const deletePost = async (req, res) => {
  const id = req.params.id;
  const { userId } = req.body;
console.log("75",req.body,req.params.id);
  try {
    const post = await PostModel.findById(id);
    if (post.id === id) {
      await post.deleteOne();
      res.status(200).json("Post deleted.");
    } else {
      res.status(403).json("Action forbidden");
    }
  } catch (error) {
    res.status(500).json(error);
  }
};

// like/dislike a post
export const likePost = async (req, res) => {
  const id = req.params.id;
  const { userId } = req.body;
  try {
    const post = await PostModel.findById(id);
    if (post.likes.includes(userId)) {
      await post.updateOne({ $pull: { likes: userId } });
      res.status(200).json("Post liked removed");
    } else {
      await post.updateOne({ $push: { likes: userId } });
      res.status(200).json("Post liked added");
    }
  } catch (error) {
    res.status(500).json(error);
  }
};

export const dislikePost = async (req, res) => {
  const id = req.params.id;
  const { userId } = req.body;
  console.log(userId);
  try {
    const post = await PostModel.findById(id);
    if (post.dislikes.includes(userId)) {
      await post.updateOne({ $pull: { dislikes: userId } });
      res.status(200).json("Post disliked removed");
    } else {
      await post.updateOne({ $push: { dislikes: userId } });
      res.status(200).json("Post disliked added");
    }
  } catch (error) {
    res.status(500).json(error);
  }
};

export const commentfetch = async (req, res) => {
  const { userId, postId } = req.params;
  const post = await PostModel.findById(postId);

  try {

    if (!post) {
      return res.status(404).json({ error: 'Post not found' });
    }

    // Return comments for the post
    res.status(200).json(post.comments);
  } catch (error) {
    console.error('Error fetching comments:', error);
    res.status(500).json({ error: 'Failed to fetch comments' });
  }
};



export const commentPost = async (req, res) => {

  const postId = req.params.id;
  const { postIDCheck, newText, commentSetID } = req.body;
  console.log("commentSetID", postIDCheck, newText, req.body);
  try {

    const post = await PostModel.findById(postId);
    console.log(post);
    if (!post) {
      return res.status(404).json({ error: 'Post not found' });
    }

    const newComment = {
      postID: postIDCheck,
      newText: newText,
      createdAt: new Date(),// Optionally add a createdAt timestamp
      commentsetID: commentSetID
    };
    post.comments.push(newComment);
    post.save()
    res.status(200).json({ message: 'Comment added successfully', post: post });

  } catch (error) {

    console.error('Error adding comment:', error);

    res.status(500).json({ error: 'Failed to add comment' });

  }
}

export const editComment = async (postId, commentId, newText) => {

  console.log("177", commentId);
  try {
    const post = await PostModel.findById(postId);
    if (!post) {
      return { success: false, message: 'Post not found' };
    }
    console.log("183", post, commentId);
    const comment = post.comments.find(comment => (comment._id).toString() == commentId);

    console.log("186", comment, commentId);
    if (!comment) {
      return { success: false, message: 'Comment not found' };
    }
    comment.newText = newText;
    await post.save();
    return { success: true, message: 'Comment updated successfully' };
    // res.status(200).json(updatedComment);

  } catch (error) {
    console.error('Error editing comment:', error.response ? error.response.data : error.message);
  }

}
export const deleteComment=async(req, res) =>{
  const { postId, commentID } = req.params;
console.log(req.params);
  try {
      const post = await PostModel.findById(postId);
      if (!post) {
          return res.status(404).send('Post not found');
      }

      post.comments = post.comments.filter(comment => comment._id.toString() !== commentID);
      await post.save();

      res.status(200).end();
  } catch (error) {
      console.error('Error deleting comment:', error);
      res.status(500).send('Error deleting comment');
  }
}


// Get timeline posts
export const getTimelinePosts = async (req, res) => {
  const userId = req.params.id
  try {
    const currentUserPosts = await PostModel.find({ userId: userId });

    const followingPosts = await UserModel.aggregate([
      {
        $match: {
          _id: new mongoose.Types.ObjectId(userId),
        },
      },
      {
        $lookup: {
          from: "posts",
          localField: "following",
          foreignField: "userId",
          as: "followingPosts",
        },
      },
      {
        $project: {
          followingPosts: 1,
          _id: 0,
        },
      },
    ]);

    res.status(200).json(
      currentUserPosts
        .concat(...followingPosts[0].followingPosts)
        .sort((a, b) => {
          return new Date(b.createdAt) - new Date(a.createdAt);
        })
    );
  } catch (error) {
    res.status(500).json(error);
  }
};

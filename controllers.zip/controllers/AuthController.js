import UserModel from "../models/userModel.js";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";

export const JWTKEY="Nivetha"
// Register new user
export const registerUser = async (req, res) => {
  console.log(" 77 value", req.body);

  const salt = await bcrypt.genSalt(10);
  const hashedPass = await bcrypt.hash(req.body.password, salt);
  req.body.password = hashedPass
  const newUser = new UserModel(req.body);
  const { username } = req.body

  try {
    // addition new
    const oldUser = await UserModel.findOne({ username });


    if (oldUser)
      return res.status(400).json({ message: "User already exists" });

    // changed
    const user = await newUser.save();
    const token = jwt.sign(
      { username: user.username, id: user._id },
      JWTKEY,
      { expiresIn: "1h" }
    );
    console.log("30 auth contoller user:", user, token);
    res.status(200).json({ user, token });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Login User

// Changed
export const loginUser = async (req, res) => {
  const { username, password } = req.body;
  console.log("44", req.body);

  try {
    const user = await UserModel.findOne({ username: username });
    console.log("1111", user);

    if (user) {

      const validity = await bcrypt.compare(password, user.password);

      console.log("52 auth contoller user:", validity);

      if (!validity) {
        res.status(400).json("wrong password");
      } else {
        console.log("63 auth contoller user:", user.username, user._id);
        const token = jwt.sign(
          { username: user.username, id: user._id },
          JWTKEY,
          { expiresIn: "1h" }
        );
        console.log("63 auth contoller user:", token);
        console.log("61 auth contoller user:", user, token);

        res.status(200).json({ user, token });
      }
    } else {

      res.status(404).json("User not found");
    }
  } catch (err) {
    res.status(500).json(err);
  }
};

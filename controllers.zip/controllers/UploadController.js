import {imageSchema } from('../models/imageModels');


export default getAllImages = async (req, res) => {
  try {
    const images = await imageSchema.find();
    res.json(images);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
};  
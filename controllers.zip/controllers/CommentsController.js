import Comment from '../models/';

// Get all comments
export const getAllComments = async (req, res) => {
    try {
        const comments = await Comment.find();
        res.json(comments);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

// Edit a comment
export const editComment = async (req, res) => {
    try {
        const comment = await Comment.findById(req.params.id);
        if (comment == null) {
            return res.status(404).json({ message: 'Comment not found' });
        }
        comment.text = req.body.text;
        await comment.save();
        res.json({ message: 'Comment updated' });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

// update a comment
export const updatedComments = async (req, res) => {
    console.log("aas", req);

    try {
        const comment = await comment.findById(req.params.id);
        if (comment == null) {
            return res.status(404).json({ message: 'Comment not found' });
        }
        comment.text = req.body.text;
        await post.updateOne({ $set: req.body });

        await comment.save();
        res.json({ message: 'Comment updated' });
    } catch (error) {
        res.status(500).json({ message: err.message });
    }
}


// Delete a comment
export const deleteComment = async (req, res) => {
    try {
        const comment = await Comment.findById(req.params.id);
        if (comment == null) {
            return res.status(404).json({ message: 'Comment not found' });
        }
        await comment.remove();
        res.json({ message: 'Comment deleted' });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};


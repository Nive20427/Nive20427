import express from 'express'
import { createPost, deletePost, getPost, getTimelinePosts, likePost, dislikePost, updatePost, commentPost, commentfetch, editComment,deleteComment } from '../controllers/PostController.js';
import authMiddleWare from '../middleware/AuthMiddleware.js';
const router = express.Router()

router.post('/', createPost)
router.get('/:id', getPost)
router.put('/:id', updatePost)
router.delete('/:id', deletePost)
router.put('/:id/like', likePost)
router.post('/:id/dislike', dislikePost);
router.get('/:id/timeline', getTimelinePosts)
router.post('/:id/comment', commentPost)
/// Assuming User model includes posts with comments

// GET comments for a specific post
router.get('/:postId/comments', commentfetch);
router.put('/:postId/comments/:commentID', async (req, res) => {
    const { postId, commentID } = req.params;
    const { newText } = req.body;
    console.log(postId, commentID, req.params);
    const result = await editComment(postId, commentID, newText);
    res.json(result);
}

)
router.delete('/:postId/comments/:commentID', deleteComment);

export default router;
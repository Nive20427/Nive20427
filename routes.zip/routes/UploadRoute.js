import express from 'express';
const router = express.Router();
import multer from 'multer';

// import path from 'path';
// import imageSchema from '../models/imageModels';


const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'public/images');
  },
  filename: (req, file, cb) => {
    cb(null, req.body.name);
    // cb(null, ` ${Date.now()}_${file.originalname}`)
  },
});
const upload = multer({ storage: storage });


router.post("/upload", upload.single("image"), async (req, res) => {

  // try {
  //   const { name, description } = req.body;
  //   const imageUrl = `${req.protocol}://${req.get('host')}/images/${req.file.filename}`;

  //   const newImage = new Image({ name, description, imageUrl });
  //   await newImage.save();
  //   res.status(201).json({ message: 'Image uploaded successfully', imageUrl });
  // } catch (err) {
  //   console.error(err);
  //   res.status(500).json({ error: 'Internal server error' });
  // }

  try {
    console.log(file,"file")
    return res.status(200).json("File uploded successfully");
  } catch (error) {
    console.error(error);
  }
});


export default router;


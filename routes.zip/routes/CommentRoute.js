import express from 'express';
import CommentsModel from '../models/commentModels';

const router = express.Router();

// Get all comments
router.get('/', async (req, res) => {
    try {
        const comments = await CommentsModel.find();
        res.json(comments);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Edit a comment
router.put('/:id', async (req, res) => {
    try {
        const comment = await CommentsModel.findById(req.params.id);
        if (comment == null) {
            return res.status(404).json({ message: 'Comment not found' });
        }
        comment.text = req.body.text;
        await comment.save();
        res.json({ message: 'Comment updated' });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

router.post('/post/:id/comment', async (req, res) => {
    console.log("aa",req,res);
    try {
        const comment = await CommentsModel.findByOne(req.params.id);
        if (comment == null) {
            return res.status(404).json({ message: 'Comment not found' });
        }
        comment.text = req.body.text;
        await comment.save();
        res.json({ message: 'Comment updated' });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Delete a comment
router.delete('/:id', async (req, res) => {
    try {
        const comment = await CommentsModel.findById(req.params.id);
        if (comment == null) {
            return res.status(404).json({ message: 'Comment not found' });
        }
        await comment.remove();
        res.json({ message: 'Comment deleted' });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

export default router;
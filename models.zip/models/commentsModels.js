import mongoose from 'mongoose';
function generateCommentId() {
    // const timestamp = Date.now().toString(36); // Base-36 timestamp for shorter IDs
    const randomString = Math.random().toString(36).substring(2, 7); // Random string for uniqueness
    return `${randomString}`;
  }

const commentSchema = new mongoose.Schema({
    commentID: {
        type: String,
        required: true,
        unique: true
    },
    newText: {
        type: String,
        required: true,
    },
    postID: {
        type: String,
        required: true,
    },
    createdAt:{
        type:Date,
        required:false
    }

});

const CommentsModels = mongoose.model('Comment', commentSchema);
export default CommentsModels;